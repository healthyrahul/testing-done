"""Auto-generated python permissions constants module."""


class ResourceObject:
    def __init__(self, name: str, display_name: str, category: str, scopes: list):
        self.name: str = name
        self.display_name: str = display_name
        self.category: str = category
        self.scopes: str = scopes


class Scope:
    VIEW = "view"
    GRANT = "grant"
    EDIT = "edit"
    CREATE = "create"
    DELETE = "delete"
    PIN_TO = "pin to"
    EXPORT = "export"
    HAVE = "have"
    ENABLE = "enable"
    DISABLE = "disable"
    DOWNLOAD = "download"


class Resource:
    ACTIONABLE_OVERSPENDING = ResourceObject(
        name="actionable overspending",
        display_name="Actionable Overspending",
        category="Actionable Overspending",
        scopes=[Scope.VIEW, Scope.GRANT],
    )
    AVOIDABLE_ER = ResourceObject(
        name="avoidable er",
        display_name="Avoidable ER",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    INAPPROPRIATE_RX_QUANTITY = ResourceObject(
        name="inappropriate rx quantity",
        display_name="Inappropriate Rx Quantity",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    INEFFICIENT_RX = ResourceObject(
        name="inefficient rx",
        display_name="Inefficient Rx",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    IN_NETWORK_VARIANCE = ResourceObject(
        name="in-network variance",
        display_name="In-Network Variance",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    OUT_OF_NETWORK = ResourceObject(
        name="out of network",
        display_name="Out of Network",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    AVOIDABLE_INPATIENT_ADMISSIONS = ResourceObject(
        name="avoidable inpatient admissions",
        display_name="Avoidable Inpatient Admissions",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    AVOIDABLE_30_DAY_READMISSIONS = ResourceObject(
        name="avoidable 30-day readmissions",
        display_name="Avoidable 30day Readmissions",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    AMBULATORY_SURGERY = ResourceObject(
        name="ambulatory surgery",
        display_name="Ambulatory Surgery",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    CHRONIC_DISEASE_COMPLICATIONS = ResourceObject(
        name="chronic disease complications",
        display_name="Chronic Disease Complications",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    MAIL_ORDER_VS_PHARMACY = ResourceObject(
        name="mail order vs pharmacy",
        display_name="Mail Order Vs. Retail Pharmacy",
        category="Actionable Overspending",
        scopes=[Scope.VIEW],
    )
    SETTINGS = ResourceObject(
        name="settings",
        display_name="Settings",
        category="Admin",
        scopes=[Scope.VIEW, Scope.EDIT],
    )
    ADMIN = ResourceObject(
        name="admin",
        display_name="Admin",
        category="Admin",
        scopes=[Scope.VIEW],
    )
    ROLES = ResourceObject(
        name="roles",
        display_name="Roles",
        category="Admin",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    USERS = ResourceObject(
        name="users",
        display_name="Users",
        category="Admin",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    BENCHMARKS = ResourceObject(
        name="benchmarks",
        display_name="Benchmarks",
        category="Benchmarks",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    RX_CLAIMS = ResourceObject(
        name="rx claims",
        display_name="Rx Claims App",
        category="Claims",
        scopes=[Scope.VIEW],
    )
    COHORTS = ResourceObject(
        name="cohorts",
        display_name="Cohorts",
        category="Cohorts",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    CUSTOM_BREAKDOWNS = ResourceObject(
        name="custom breakdowns",
        display_name="Custom Breakdowns",
        category="Custom Breakdowns",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    EXPLORE = ResourceObject(
        name="explore",
        display_name="Explorations",
        category="Explore",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    FILTERS = ResourceObject(
        name="filters",
        display_name="Filters",
        category="Filters",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW, Scope.GRANT],
    )
    HOME = ResourceObject(
        name="home",
        display_name="Home",
        category="Home",
        scopes=[Scope.PIN_TO, Scope.VIEW],
    )
    INITIATIVES = ResourceObject(
        name="initiatives",
        display_name="Initiatives",
        category="Initiatives",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    MEMBERS = ResourceObject(
        name="members",
        display_name="Members",
        category="Members",
        scopes=[Scope.VIEW],
    )
    NEW_PROGRAM_SAVINGS = ResourceObject(
        name="new program savings",
        display_name="New Program Savings",
        category="New Program Savings",
        scopes=[Scope.VIEW, Scope.GRANT],
    )
    CDHP = ResourceObject(
        name="cdhp",
        display_name="CDHP",
        category="New Program Savings",
        scopes=[Scope.VIEW],
    )
    ON_SITE_CLINIC = ResourceObject(
        name="on-site clinic",
        display_name="On-site Clinic",
        category="New Program Savings",
        scopes=[Scope.VIEW],
    )
    PRICE_TRANSPARENCY_TOOL = ResourceObject(
        name="price transparency tool",
        display_name="Price Transparency Tool",
        category="New Program Savings",
        scopes=[Scope.VIEW],
    )
    TELEMEDICINE = ResourceObject(
        name="telemedicine",
        display_name="Telemedicine",
        category="New Program Savings",
        scopes=[Scope.VIEW],
    )
    SLICES = ResourceObject(
        name="slices",
        display_name="Slices",
        category="Slices",
        scopes=[Scope.CREATE, Scope.EDIT, Scope.DELETE, Scope.VIEW],
    )
    STORIES = ResourceObject(
        name="stories",
        display_name="Stories",
        category="stories",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW, Scope.GRANT],
    )
    VISUALIZE = ResourceObject(
        name="visualize",
        display_name="Visualizations",
        category="Visualize",
        scopes=[Scope.CREATE, Scope.EDIT, Scope.DELETE, Scope.VIEW, Scope.GRANT],
    )
    FOLDERS = ResourceObject(
        name="folders",
        display_name="Folders",
        category="Folders",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.GRANT, Scope.VIEW],
    )
    SHARE = ResourceObject(
        name="share",
        display_name="Share",
        category="Sharing",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.GRANT, Scope.VIEW],
    )
    TIEOUT_REPORTS = ResourceObject(
        name="tieout reports",
        display_name="Tieout Reports",
        category="Tieout Reports",
        scopes=[Scope.GRANT, Scope.CREATE, Scope.EDIT, Scope.VIEW, Scope.DELETE],
    )
    SUBCOMPANY = ResourceObject(
        name="subcompany",
        display_name="Subcompany",
        category="Subcompany",
        scopes=[Scope.GRANT, Scope.CREATE, Scope.EDIT, Scope.VIEW, Scope.DELETE],
    )
    COMPANY = ResourceObject(
        name="company",
        display_name="Company",
        category="Copmany",
        scopes=[Scope.GRANT, Scope.CREATE, Scope.EDIT, Scope.VIEW, Scope.DELETE],
    )
    SQL_BUILDER = ResourceObject(
        name="sql builder",
        display_name="SQL builder",
        category="Visualize",
        scopes=[Scope.VIEW],
    )
    CHAT = ResourceObject(
        name="chat",
        display_name="Chat Support",
        category="Chat",
        scopes=[Scope.VIEW],
    )
    PII = ResourceObject(
        name="pii",
        display_name="PII",
        category="Members",
        scopes=[Scope.VIEW, Scope.EXPORT],
    )
    MEDICAL_CLAIM_LINES = ResourceObject(
        name="medical claim lines",
        display_name="Medical Claim Lines App",
        category="Claims",
        scopes=[Scope.VIEW],
    )
    ADVANCED_FILTERS = ResourceObject(
        name="advanced filters",
        display_name="Advanced Filters",
        category="Filters",
        scopes=[Scope.CREATE, Scope.VIEW, Scope.EDIT],
    )
    TABLE_VIEWS = ResourceObject(
        name="table views",
        display_name="Table Views",
        category="Table Views",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    PROVIDERS = ResourceObject(
        name="providers",
        display_name="Providers App",
        category="Providers",
        scopes=[Scope.VIEW],
    )
    MEMBER_DATA_SESSION = ResourceObject(
        name="member data session",
        display_name="Member Data Session",
        category="Members",
        scopes=[Scope.HAVE],
    )
    STANDARD_STORIES = ResourceObject(
        name="standard stories",
        display_name="Standard Stories",
        category="Standard Stories",
        scopes=[Scope.VIEW],
    )
    SSO = ResourceObject(
        name="sso",
        display_name="SSO",
        category="Single Sign On",
        scopes=[Scope.ENABLE, Scope.DISABLE, Scope.EDIT, Scope.VIEW],
    )
    STANDARD_STORIES_DOWNLOAD_CONFIG = ResourceObject(
        name="standard stories download config",
        display_name="Standard Stories PDF download configuration",
        category="Standard Stories",
        scopes=[Scope.EDIT],
    )
    SINGLE_STORY = ResourceObject(
        name="single story",
        display_name="Single Standard Story",
        category="Standard Stories",
        scopes=[Scope.DOWNLOAD],
    )
    MULTIPLE_STORIES_FROM_SINGLE_COMPANY = ResourceObject(
        name="multiple stories from single company",
        display_name="Multiple Standard Stories from One Company",
        category="Standard Stories",
        scopes=[Scope.DOWNLOAD],
    )
    MULTIPLE_STORIES_FROM_MULTIPLE_COMPANIES = ResourceObject(
        name="multiple stories from multiple companies",
        display_name="Multiple Standard Stories from Multiple Companies",
        category="Standard Stories",
        scopes=[Scope.DOWNLOAD],
    )
    CUSTOM_MEASURES = ResourceObject(
        name="custom measures",
        display_name="Custom Measures",
        category="Custom Measures",
        scopes=[Scope.CREATE, Scope.EDIT, Scope.VIEW, Scope.DELETE],
    )
    PHYSICIAN_SCORES = ResourceObject(
        name="physician scores",
        display_name="Physician Score Views",
        category="Physician Scores",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW],
    )
    HOSPITAL_SCORES = ResourceObject(
        name="hospital scores",
        display_name="Hospital Scores Views",
        category="Hospital Scores",
        scopes=[Scope.CREATE, Scope.EDIT, Scope.DELETE, Scope.VIEW],
    )
    MILLIMAN_BENCHMARKS = ResourceObject(
        name="milliman benchmarks",
        display_name="Milliman Benchmarks",
        category="Benchmarks",
        scopes=[Scope.VIEW],
    )
    TREND_EXPLORER = ResourceObject(
        name="trend explorer",
        display_name="Trend Explorer",
        category="Benchmarks",
        scopes=[Scope.VIEW],
    )
    ARTEMIS_BENCHMARKS = ResourceObject(
        name="artemis benchmarks",
        display_name="Artemis Benchmarks",
        category="Benchmarks",
        scopes=[Scope.VIEW],
    )
    FINANCIAL_REPORTING = ResourceObject(
        name="financial reporting",
        display_name="Financial Reporting Views",
        category="Financial Reporting",
        scopes=[Scope.CREATE, Scope.DELETE, Scope.EDIT, Scope.VIEW, Scope.GRANT],
    )
    PERSPECTIVES = ResourceObject(
        name="perspectives",
        display_name="Perspectives",
        category="Perspectives",
        scopes=[Scope.VIEW],
    )
    COST_ADVISOR = ResourceObject(
        name="cost advisor",
        display_name="Cost Advisor",
        category="Cost Advisor",
        scopes=[Scope.VIEW],
    )
    CONSOLE = ResourceObject(
        name="console",
        display_name="Console",
        category="Console",
        scopes=[Scope.VIEW],
    )
    ESSENTIALS_BASE_OFFERING = ResourceObject(
        name="essentials base offering",
        display_name="Essentials Base Offering",
        category="Standard Stories",
        scopes=[Scope.DOWNLOAD],
    )
