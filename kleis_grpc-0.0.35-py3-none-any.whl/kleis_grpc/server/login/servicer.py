"""Implementations of Login Related gRPC Servicers."""
# pylint: disable=no-member
import logging

import requests
from grpc._server import _Context  # type: ignore
from keycloak.exceptions import (  # type: ignore
    KeycloakAuthenticationError,
    KeycloakConnectionError,
    KeycloakPostError,
)

from kleis_grpc.protos.authentication import login_pb2, login_pb2_grpc
from kleis_grpc.protos.general import statuses_pb2
from kleis_grpc.server.exceptions import InvalidSaml, KeycloakUnavailable
from kleis_grpc.server.utils import keycloak_utils
from kleis_grpc.server.utils.saml_login_manager import KeycloakSamlHandler


LOGGER = logging.getLogger(__name__)


class LoginServicer(
    login_pb2_grpc.LoginServicer
):  # pylint: disable=too-few-public-methods
    """Implementation of the LoginServicer gRPC codestub."""

    def passwordLogin(
        self, request: login_pb2.PasswordLoginRequest, context: _Context
    ) -> login_pb2.LoginResponse:
        """Exchange a user_id (email) and password for a JWT pair."""
        # Default to UNKNOWN status, in case everything is broken.
        response = login_pb2.LoginResponse(status=statuses_pb2.UNKNOWN)
        try:
            keycloak_client = keycloak_utils.get_keycloak_client()
            response = keycloak_client.token(request.user_id, request.password)
            access_token = response.get("access_token")
            refresh_token = response.get("refresh_token")
            response = login_pb2.LoginResponse(
                status=statuses_pb2.OK,
                access_token=access_token,
                refresh_token=refresh_token,
            )
        except KeycloakAuthenticationError:
            response = login_pb2.LoginResponse(status=statuses_pb2.INVALID_CREDENTIALS)
        except (
            KeycloakConnectionError,
            KeycloakPostError,
        ):
            response = login_pb2.LoginResponse(status=statuses_pb2.SERVICE_UNAVAILABLE)
            LOGGER.exception("Unable to connect to keycloak.")
        except Exception:  # pylint: disable=broad-exception-caught
            LOGGER.exception("Unknown Error Occurred")
        return response

    def IDPInitiatedLogin(
        self, request: login_pb2.IDPInitiatedLoginRequest, context: _Context
    ) -> login_pb2.LoginResponse:
        """Exchange a SAML assertion for a JWT pair."""
        # Default to UNKNOWN status, in case everything is broken.
        r_proto = login_pb2.LoginResponse
        response = r_proto(status=statuses_pb2.UNKNOWN)
        try:
            tokens = KeycloakSamlHandler().idp_saml_login(
                request.saml_assertion,
            )
            response = r_proto(
                status=statuses_pb2.OK,
                access_token=tokens.get("access_token"),
                refresh_token=tokens.get("refresh_token"),
            )
        except InvalidSaml:
            response = r_proto(status=statuses_pb2.INVALID_CREDENTIALS)
        except (requests.exceptions.ConnectionError, KeycloakUnavailable):
            response = r_proto(status=statuses_pb2.SERVICE_UNAVAILABLE)
            LOGGER.exception("Unable to connect to keycloak.")
        except Exception:  # pylint: disable=broad-exception-caught
            LOGGER.exception("Unknown Error Occurred")
        return response

    def GenerateSPInitiatedLogin(
        self, request: login_pb2.GenerateSPInitiatedLoginRequest, context: _Context
    ) -> login_pb2.GenerateSPInitiatedLoginResponse:
        """Generate an SP-initiated SAML request."""
        r_proto = login_pb2.GenerateSPInitiatedLoginResponse
        response = r_proto(status=statuses_pb2.UNKNOWN)
        try:
            sp_context = KeycloakSamlHandler().generate_sp_initiated_request(
                subject=request.username,
                frontend_destination=request.frontend_destination,
            )
            response = r_proto(
                status=statuses_pb2.OK,
                sp_saml_request=sp_context.get("saml_request"),
                relay_state=sp_context.get("relay_state"),
                sso_url=sp_context.get("provider_url"),
                session_id=sp_context.get("session_id"),
            )
        except Exception:  # pylint: disable=broad-exception-caught
            LOGGER.exception("Unknown Error Occurred")
        return response

    def SPInitiatedLogin(
        self, request: login_pb2.SPInitiatedLoginRequest, context: _Context
    ) -> login_pb2.LoginResponse:
        """Perform login for a user and obtain tokens."""
        r_proto = login_pb2.LoginResponse
        response = r_proto(status=statuses_pb2.UNKNOWN)
        try:
            tokens = KeycloakSamlHandler().sp_initiated_login(
                saml_assertion=request.saml_assertion,
                session_id=request.session_id,
                relay_state=request.relay_state,
            )
            response = r_proto(
                status=statuses_pb2.OK,
                access_token=tokens.get("access_token"),
                refresh_token=tokens.get("refresh_token"),
            )
        except Exception:  # pylint: disable=broad-exception-caught
            LOGGER.exception("Unknown Error Occurred")
        return response
