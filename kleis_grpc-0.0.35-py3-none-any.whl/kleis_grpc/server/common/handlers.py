"""Handlers for common use, not applicable to a specific servicer or category.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


def resource_server_endpoint(
    keycloak_admin: KeycloakAdmin,
    client_id: str,
) -> str:
    return (
        f"{keycloak_admin.server_url}/admin/realms/"
        f"{keycloak_admin.connection.realm_name}/clients/"
        f"{client_id}/authz/resource-server"
    )
