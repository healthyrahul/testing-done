"""Handlers for general authorization tasks.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""
from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING

from keycloak.exceptions import KeycloakInvalidTokenError

from kleis_grpc.protos.authorization import (
    permission_pb2,
    policy_pb2,
    resource_pb2,
    scope_pb2,
)
from kleis_grpc.server import settings
from kleis_grpc.server.exceptions import (
    InvalidCompany,
    KeycloakConfigurationError,
    RoleNotFound,
)
from kleis_grpc.server.permission.handlers import create_keycloak_permission
from kleis_grpc.server.policy.handlers import (
    add_role_id_to_policy_by_keycloak_dict,
    create_role_based_policy,
    get_company_policies_with_role_id_member,
    policy_url,
    remove_role_id_from_policy_by_keycloak_dict,
)
from kleis_grpc.server.resource.handlers import (
    create_resource,
    get_resource_by_name,
    update_resource,
)
from kleis_grpc.server.role.handlers import get_role
from kleis_grpc.server.scope.handlers import create_scope, get_scope_by_name


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin, KeycloakOpenID

LOGGER = logging.getLogger(__name__)


def create_permission_bundle(
    resource: str,
    scope: str,
    company_key: str,
    client_id: str,
    resource_friendly_name: str,
    resource_category: str,
    keycloak_admin: KeycloakAdmin,
) -> permission_pb2.Permission:
    """Create a "permission bundle" in the manner most compatible with with existing
    ecosystem (hermes, artemis-app). Creates resource and scope if they don't
    exist, then generates role policies, and finally a permission object that ties them
    all together.
    """
    # Get or create scope.
    scope_object = get_scope_by_name(
        scope_name=scope, client_id=client_id, keycloak_admin=keycloak_admin
    )
    if scope_object is None:
        LOGGER.info(
            f"Scope '{scope}' doesn't exist for company_key '{company_key}'. "
            "Creating now."
        )
        scope_object = create_scope(
            name=scope, client_id=client_id, keycloak_admin=keycloak_admin
        )

    # Get or create resource.
    # If resource exists, check to see if the scope has already been added (and
    # add it if not).
    resource_object = get_resource_by_name(
        resource_name=resource, client_id=client_id, keycloak_admin=keycloak_admin
    )
    if resource_object is None:
        LOGGER.info(
            f"Resource '{resource}' doesn't exist for company_key "
            f"'{company_key}'. Creating now."
        )
        resource_object = create_resource(
            name=resource,
            client_id=client_id,
            category=resource_category,
            friendly_name=resource_friendly_name,
            scopes=[scope_object["name"]],
            keycloak_admin=keycloak_admin,
        )
    else:
        resource_scopes = [scope["name"] for scope in resource_object.get("scopes", [])]
        if scope_object["name"] not in resource_scopes:
            LOGGER.info(
                f"Scope '{scope}' not yet assigned to resource '{resource}' "
                f"for company_key '{company_key}'. Assigning now."
            )
            resource_scopes.append(scope_object["name"])
            update_resource(
                name=resource_object["name"],
                company_key=company_key,
                client_id=client_id,
                updated_values={
                    "name": resource_object["name"],
                    "scopes": resource_scopes,
                },
                keycloak_admin=keycloak_admin,
            )

    # Create role policies
    positive_policy = create_role_based_policy(
        name=(
            f'{settings.POSITIVE_ROLE_POLICY_PREFIX} {scope_object["name"]} '
            f'{resource_object["name"]}'
        ),
        logic="POSITIVE",
        type="role",
        role_ids=[],
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )
    negative_policy = create_role_based_policy(
        name=(
            f'{settings.NEGATIVE_ROLE_POLICY_PREFIX} {scope_object["name"]} '
            f'{resource_object["name"]}'
        ),
        logic="NEGATIVE",
        type="role",
        role_ids=[],
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )

    # Create permission that ties it all together.
    return create_keycloak_permission(
        request=permission_pb2.Permission(
            name=f'{scope_object["name"]} {resource_object["name"]}',
            company_key=company_key,
            strategy=settings.DEFAULT_PERMISSION_STRATEGY,
            resources=[resource_pb2.Resource(name=resource_object["name"])],
            scopes=[scope_pb2.Scope(name=scope_object["name"])],
            policies=[
                policy_pb2.Policy(name=positive_policy["name"]),
                policy_pb2.Policy(name=negative_policy["name"]),
            ],
        ),
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )


def propagate_existing_role_permissions(
    role_id: str,
    role_company_key: str,
    client_id: str,
    propagated_company_key: str,
    keycloak_admin: KeycloakAdmin,
) -> None:
    """Get list of policies for the role's origin company which include the provided
    role, then add the role to the appropriate policies at the propagated company.
    """
    # company_key is validated by the servicer in this case, so we won't verify here
    policies = get_company_policies_with_role_id_member(
        policies_company_key=role_company_key,
        role_id=role_id,
        keycloak_admin=keycloak_admin,
    )
    policy_url_beginning = policy_url(
        keycloak_admin=keycloak_admin, client_id=client_id
    )

    # Thread the work for each policy that needs to be updated.
    def worker(policy: dict) -> None:
        propagated_company_policy = keycloak_admin.connection.raw_get(
            path=policy_url_beginning + f"?name={policy['name']}"
        ).json()[0]
        response = add_role_id_to_policy_by_keycloak_dict(
            policy=propagated_company_policy,
            client_id=client_id,
            role_id=role_id,
            keycloak_admin=keycloak_admin,
        )
        if not response.ok:
            LOGGER.error(
                f'No "{policy["name"]}" policy found for company '
                f"{propagated_company_key}."
            )
        return None

    num_workers = 10  # This is the default max poolsize of HTTPAdapter
    exceptions: list[Exception] = []
    with ThreadPoolExecutor(max_workers=num_workers) as executor:
        futures = (executor.submit(worker, policy) for policy in policies)
        for future in as_completed(futures):
            if exception := future.exception():
                exceptions.append(exception)
    if exceptions:
        raise ExceptionGroup("Propagation of some policies failed.", exceptions)
    return None


def unpropagate_existing_role_permissions(
    role_id: str,
    client_id: str,
    propagated_company_key: str,
    keycloak_admin: KeycloakAdmin,
) -> None:
    """Get list of policies for the propagated company which include the provided
    role, then remove the role from those policies.
    """
    # company_key is validated by the servicer in this case, so we won't verify here
    policies = get_company_policies_with_role_id_member(
        policies_company_key=propagated_company_key,
        role_id=role_id,
        keycloak_admin=keycloak_admin,
    )

    # Thread the work for each policy that needs to be updated
    def worker(policy: dict) -> None:
        remove_role_id_from_policy_by_keycloak_dict(
            policy=policy,
            client_id=client_id,
            role_id=role_id,
            keycloak_admin=keycloak_admin,
        )
        return None

    num_workers = 10  # This is the default max poolsize of HTTPAdapter
    exceptions: list[Exception] = []
    with ThreadPoolExecutor(max_workers=num_workers) as executor:
        futures = (executor.submit(worker, policy) for policy in policies)
        for future in as_completed(futures):
            if exception := future.exception():
                exceptions.append(exception)
    if exceptions:
        raise ExceptionGroup("Propagation to some policies failed.", exceptions)
    return None


def permission_is_visible_for_roles(
    permission_name: str, company_key: str, keycloak_admin: KeycloakAdmin
) -> bool:
    """Checks whether or not a permission is "visible" for a given role. It does this
    by checking to see if the permission is disabled at the "Company" role level. If so,
    the permission is not visible to the role.
    """
    try:
        company_role = get_role(
            name=settings.COMPANY_ROLE_NAME,
            company_key=company_key,
            keycloak_admin=keycloak_admin,
        )
    except RoleNotFound:
        raise RoleNotFound(
            f"Default role {settings.COMPANY_ROLE_NAME} does not exist for company "
            f"{company_key}."
        )

    # We're just going to grab the dict the way keycloak gives it to us to be faster,
    # instead of letting kleis_grpc.server.policy.handlers.get_policy() do a bunch of
    # decoration for us.
    client_id = keycloak_admin.get_client_id(company_key)
    policies = keycloak_admin.get_client_authz_policies(client_id=client_id)
    policy = next(
        (
            policy
            for policy in policies
            if policy["name"]
            == f"{settings.POSITIVE_ROLE_POLICY_PREFIX} {permission_name}"
        ),
        None,
    )
    policy_roles = json.loads(policy["config"].get("roles", "[]"))
    return company_role.id in [role["id"] for role in policy_roles]


def exchange_token(
    access_token: str, new_company_key: str, openid_client: KeycloakOpenID
) -> dict:
    token_exchange_endpoint = (
        f"{openid_client.connection.base_url}/realms/{openid_client.realm_name}"
        "/protocol/openid-connect/token"
    )
    payload = {
        "client_id": settings.KEYCLOAK_CLIENT_ID,
        "client_secret": settings.KEYCLOAK_CLIENT_SECRET_KEY,
        "audience": new_company_key,
        "subject_token": access_token,
        "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
        "requested_token_type": "urn:ietf:params:oauth:token-type:refresh_token",
    }
    response = openid_client.connection.raw_post(
        path=token_exchange_endpoint,
        data=payload,
    )
    if response.ok:
        return response.json()
    elif response.status_code == 401:
        raise InvalidCompany(
            "Company client not found in keycloak (or bad credentials)"
        )
    elif response.status_code == 403:
        raise KeycloakConfigurationError(
            "Client does not have token-exchange permissions."
        )
    elif response.status_code == 400:
        raise KeycloakInvalidTokenError
    else:
        LOGGER.error(
            f"Unknown response from token-exchange endpoint: {response.status_code} "
            f"{response.json()}"
        )
        return {}
