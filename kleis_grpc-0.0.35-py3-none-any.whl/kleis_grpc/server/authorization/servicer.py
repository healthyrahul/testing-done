from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING, List, Tuple

from google.rpc import code_pb2, status_pb2
from grpc._server import _Context  # type: ignore
from grpc_status import rpc_status
from keycloak.exceptions import KeycloakGetError, KeycloakInvalidTokenError

from kleis_grpc.protos.authorization import (
    authorization_pb2,
    authorization_pb2_grpc,
    permission_pb2,
)
from kleis_grpc.server import settings
from kleis_grpc.server.authorization.handlers import (
    create_permission_bundle,
    exchange_token,
    permission_is_visible_for_roles,
)
from kleis_grpc.server.exceptions import (
    CompanyNotFound,
    InvalidCompany,
    KeycloakConfigurationError,
    PolicyNotFound,
    RoleNotFound,
    TokenExchangeFailed,
)
from kleis_grpc.server.policy.handlers import (
    add_role_id_to_policy_by_keycloak_dict,
    add_role_to_policy,
    get_policy,
    policy_url,
    remove_role_from_policy,
    remove_role_id_from_policy_by_keycloak_dict,
)
from kleis_grpc.server.role.handlers import get_role
from kleis_grpc.server.utils import keycloak_utils


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


class AuthorizationServicer(authorization_pb2_grpc.AuthorizationServiceServicer):
    def _check_permission_prereqs(
        self, permission_name: str, client_id: str, keycloak_admin: KeycloakAdmin
    ) -> Tuple[dict, dict]:
        """Return the positive and negative role policies for a permission. Looks up via
        a query filter on the keycloak endpoint instead of using the SDK, in order to be
        much faster.
        """
        policy_url_beginning = policy_url(
            keycloak_admin=keycloak_admin, client_id=client_id
        )
        pos_policy_name = (
            f"{settings.POSITIVE_ROLE_POLICY_PREFIX} " f"{permission_name}"
        )
        neg_policy_name = (
            f"{settings.NEGATIVE_ROLE_POLICY_PREFIX} " f"{permission_name}"
        )
        pos_policy_response = keycloak_admin.connection.raw_get(
            path=policy_url_beginning + f"?name={pos_policy_name}"
        )

        neg_policy_response = keycloak_admin.connection.raw_get(
            path=policy_url_beginning + f"?name={neg_policy_name}"
        )
        try:
            # JSON response is a list containing a single dict
            pos_policy = pos_policy_response.json()[0]
            neg_policy = neg_policy_response.json()[0]
            return pos_policy, neg_policy
        except IndexError:
            LOGGER.exception(
                "One or more required policies not found for permission "
                f'"{permission_name}" on client_id {client_id}.'
            )
            return {}, {}

    def _multi_client_permission_enable(
        self,
        permission_name: str,
        company_keys: List[str],
        role_id: str,
        keycloak_admin: KeycloakAdmin,
    ) -> List[dict]:
        def worker(company_key: str) -> Tuple[str, bool]:
            try:
                client_id = keycloak_admin.get_client_id(company_key)
                if client_id is None:
                    LOGGER.error(
                        f"No keycloak client found for company_key {company_key}"
                    )
                    return company_key, False
                policy_response, _ = self._check_permission_prereqs(
                    permission_name=permission_name,
                    client_id=client_id,
                    keycloak_admin=keycloak_admin,
                )
                if not policy_response:
                    return company_key, False
                add_role_id_to_policy_by_keycloak_dict(
                    policy=policy_response,
                    client_id=client_id,
                    role_id=role_id,
                    keycloak_admin=keycloak_admin,
                )
                return company_key, True
            except KeycloakGetError:
                LOGGER.error(
                    "Unable to propagate permission changes to "
                    f"{company_key} as company no longer exists in Keycloak."
                )
                return company_key, False

        num_workers = 10  # This is the default max poolsize of HTTPAdapter
        exceptions: list[Exception] = []
        results: list[dict] = []
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = (
                executor.submit(worker, company_key) for company_key in company_keys
            )
            for future in as_completed(futures):
                if exception := future.exception():
                    exceptions.append(exception)
                else:
                    result_company_key, result = future.result()
                    results.append({result_company_key: result})
        if exceptions:
            raise ExceptionGroup(
                "Propagation of permission setting failed to some companies.",
                exceptions,
            )
        return results

    def _multi_client_permission_disable(
        self,
        permission_name: str,
        company_keys: List[str],
        role_id: str,
        keycloak_admin: KeycloakAdmin,
    ) -> List[dict]:
        def worker(company_key: str) -> Tuple[str, bool]:
            try:
                client_id = keycloak_admin.get_client_id(company_key)
                if client_id is None:
                    LOGGER.error(
                        f"No keycloak client found for company_key {company_key}"
                    )
                    return company_key, False
                policy_response, _ = self._check_permission_prereqs(
                    permission_name=permission_name,
                    client_id=client_id,
                    keycloak_admin=keycloak_admin,
                )
                if not policy_response:
                    return company_key, False
                remove_role_id_from_policy_by_keycloak_dict(
                    policy=policy_response,
                    client_id=client_id,
                    role_id=role_id,
                    keycloak_admin=keycloak_admin,
                )
                return company_key, True
            except KeycloakGetError:
                LOGGER.error(
                    "Unable to propagate permission changes to "
                    f"{company_key} as company no longer exists in Keycloak."
                )
                return company_key, False

        num_workers = 10  # This is the default max poolsize of HTTPAdapter
        exceptions: list[Exception] = []
        results: list[dict] = []
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = (
                executor.submit(worker, company_key) for company_key in company_keys
            )
            for future in as_completed(futures):
                if exception := future.exception():
                    exceptions.append(exception)
                else:
                    result_company_key, result = future.result()
                    results.append({result_company_key: result})
        if exceptions:
            raise ExceptionGroup(
                "Propagation of permission setting failed to some companies.",
                exceptions,
            )
        return results

    def enablePermissionForRole(
        self, request: authorization_pb2.PermissionToggleRequest, context: _Context
    ) -> authorization_pb2.PermissionToggleResponse:
        """Enables permission for a role and cycles through the propagated_companies
        key to enable the permission for any companies the role is propagated to as
        well, by adding the role to the role policy for each applicable
        client>permission.
        """
        permission_name = request.scope + " " + request.resource
        keycloak_admin = keycloak_utils.get_keycloak_admin()

        local_get_role = get_role
        local_check_perm_prereqs = self._check_permission_prereqs
        local_add_role_to_policy = add_role_id_to_policy_by_keycloak_dict

        # Add role to policy for the company
        # Firstly confirm existence of all needed parts
        try:
            role_response = local_get_role(
                name=request.role_name,
                company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )
        except RoleNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Role not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        client_id = keycloak_admin.get_client_id(request.company_key)
        pos_policy_response, neg_policy_response = local_check_perm_prereqs(
            client_id=client_id,
            permission_name=permission_name,
            keycloak_admin=keycloak_admin,
        )
        if not pos_policy_response or not neg_policy_response:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND,
                message="One or more required policies not found.",
            )
            context.abort_with_status(rpc_status.to_status(status))
        # If it's disabled at the Company level, you can't enable the permission.
        # This is a convenience feature mostly, because the restrictive negative role
        # policy for Company roles will also "mask" the permission.
        if (
            request.role_name != settings.COMPANY_ROLE_NAME
            and not permission_is_visible_for_roles(
                permission_name=permission_name,
                company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )
        ):
            status = status_pb2.Status(
                code=code_pb2.PERMISSION_DENIED,
                message="Permission not visible to role.",
            )
            context.abort_with_status(rpc_status.to_status(status))

        local_add_role_to_policy(
            policy=pos_policy_response,
            client_id=client_id,
            role_id=role_response.id,
            keycloak_admin=keycloak_admin,
        )

        # If we're modifying the Company role, we need to remove it from the negative
        # policy.
        if request.role_name == settings.COMPANY_ROLE_NAME:
            remove_role_from_policy(
                policy_name=neg_policy_response["name"],
                policy_company_key=role_response.company_key,
                role_name=role_response.name,
                role_company_key=role_response.company_key,
                keycloak_admin=keycloak_admin,
            )

        # Get list of propagated company keys
        # Loop through each key and add role to policy for each one
        # For speed, we have to trust that each key in the list is a valid client
        # (that's validated when adding a company to the list, but it's possible a
        # company/client could have been deleted after being added to the
        # propagated_companies list)
        if role_response.propagated_companies:
            self._multi_client_permission_enable(
                permission_name=permission_name,
                company_keys=role_response.propagated_companies,
                role_id=role_response.id,
                keycloak_admin=keycloak_admin,
            )
        return authorization_pb2.PermissionToggleResponse()

    def disablePermissionForRole(
        self, request: authorization_pb2.PermissionToggleRequest, context: _Context
    ) -> authorization_pb2.PermissionToggleResponse:
        """Disables permission for a role and cycles through the propagated_companies
        key to disable the permission for any companies the role is propagated to as
        well, by removing the role from the role policy for each applicable
        client>permission.
        """
        permission_name = request.scope + " " + request.resource
        keycloak_admin = keycloak_utils.get_keycloak_admin()

        # Add role to policy for the company
        # Firstly confirm existence of all needed parts
        try:
            role_response = get_role(
                name=request.role_name,
                company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )
        except RoleNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Role not found."
            )
            context.abort_with_status(rpc_status.to_status(status))

        client_id = keycloak_admin.get_client_id(request.company_key)
        pos_policy_response, neg_policy_response = self._check_permission_prereqs(
            client_id=client_id,
            permission_name=permission_name,
            keycloak_admin=keycloak_admin,
        )
        if not pos_policy_response or not neg_policy_response:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND,
                message="One or more required policies not found.",
            )
            context.abort_with_status(rpc_status.to_status(status))
        remove_role_id_from_policy_by_keycloak_dict(
            policy=pos_policy_response,
            client_id=client_id,
            role_id=role_response.id,
            keycloak_admin=keycloak_admin,
        )
        # If we're modifying the Company role, add it to the negative/restrictive policy
        if request.role_name == settings.COMPANY_ROLE_NAME:
            add_role_to_policy(
                policy_name=neg_policy_response["name"],
                policy_company_key=role_response.company_key,
                role_name=role_response.name,
                role_company_key=role_response.company_key,
                keycloak_admin=keycloak_admin,
            )

        # Get list of propagated company keys
        # Loop through each key and add role to policy for each one
        # For speed, we have to trust that each key in the list is a valid client
        # (that's validated when adding a company to the list, but it's possible a
        # company/client could have been deleted after being added to the
        # propagated_companies list)

        if role_response.propagated_companies:
            self._multi_client_permission_disable(
                permission_name=permission_name,
                company_keys=role_response.propagated_companies,
                role_id=role_response.id,
                keycloak_admin=keycloak_admin,
            )

        return authorization_pb2.PermissionToggleResponse()

    def evaluatePermission(
        self, request: authorization_pb2.EvaluatePermissionRequest, context: _Context
    ) -> authorization_pb2.EvaluatePermissionResponse:
        try:
            openid_client = keycloak_utils.get_keycloak_client()
            token = exchange_token(
                access_token=request.access_token,
                new_company_key=request.company_key,
                openid_client=openid_client,
            )
            if token == {}:
                # We had a problem with token exchange that wasn't caught
                raise TokenExchangeFailed
            # We have to tell KeycloakOpenID client which audience in the token to use
            openid_client.client_id = request.company_key
            auth_status = openid_client.has_uma_access(
                token["access_token"], f"{request.resource}#{request.scope}"
            )
            return authorization_pb2.EvaluatePermissionResponse(
                is_authorized=auth_status.is_authorized,
            )
        except (KeycloakConfigurationError, InvalidCompany, TokenExchangeFailed):
            status = status_pb2.Status(
                code=code_pb2.FAILED_PRECONDITION, message="Token exchange failed."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except KeycloakInvalidTokenError as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.PERMISSION_DENIED, message="Invalid token."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def createPermissionBundle(
        self,
        request: authorization_pb2.CreatePermissionBundleRequest,
        context: _Context,
    ) -> permission_pb2.Permission:
        """Create the full "permission bundle" (scope, resource, role policies, and
        permission object.
        """
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        return create_permission_bundle(
            resource=request.resource,
            scope=request.scope,
            company_key=request.company_key,
            client_id=client_id,
            resource_friendly_name=request.resource_friendly_name,
            resource_category=request.resource_category,
            keycloak_admin=keycloak_admin,
        )

    def getPermissionStatusForRole(
        self,
        request: authorization_pb2.PermissionStatusForRoleRequest,
        context: _Context,
    ) -> authorization_pb2.RolePermissionResponse:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        try:
            # Get the positive policy for the permission by inferred name
            permission_name = f"{request.scope} {request.resource}"
            policy_proto = get_policy(
                name=(f"{settings.POSITIVE_ROLE_POLICY_PREFIX} {permission_name}"),
                company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )
            role_proto = get_role(
                name=request.role_name,
                company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )
        except PolicyNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Required policy not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except CompanyNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except RoleNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Role not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception:
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

        # Check if the role is on the policy
        is_enabled = {
            "name": role_proto.name,
            "company_key": role_proto.company_key,
        } in (
            [
                {"name": policy_role.name, "company_key": policy_role.company_key}
                for policy_role in policy_proto.roles
            ]
        )
        is_visible = permission_is_visible_for_roles(
            permission_name=permission_name,
            company_key=role_proto.company_key,
            keycloak_admin=keycloak_admin,
        )
        return authorization_pb2.RolePermissionResponse(
            permission=permission_name,
            is_enabled=is_enabled,
            is_visible=is_visible,
        )

    def getAllPermissionStatusesForRole(
        self,
        request: authorization_pb2.AllPermissionStatusesForRoleRequest,
        context: _Context,
    ) -> authorization_pb2.RolePermissionResponse:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        # We don't strictly need to look up the role, but it's nice to check that it
        # exists.
        try:
            role_proto = get_role(
                name=request.role_name,
                company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )
        except RoleNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Role not found."
            )
            context.abort_with_status(rpc_status.to_status(status))

        company_role_proto = get_role(
            name=settings.COMPANY_ROLE_NAME,
            company_key=request.company_key,
            keycloak_admin=keycloak_admin,
        )

        permission_names = [
            permission["name"]
            for permission in (
                keycloak_admin.get_client_authz_permissions(client_id=client_id)
            )
        ]
        # Look up policies only once, then grab any needed policies out of the dict
        policies = keycloak_admin.get_client_authz_policies(client_id=client_id)
        for permission_name in permission_names:
            policy = next(
                (
                    policy
                    for policy in policies
                    if policy["name"]
                    == f"{settings.POSITIVE_ROLE_POLICY_PREFIX} {permission_name}"
                ),
                None,
            )
            if policy is not None:
                policy_roles = json.loads(policy["config"].get("roles", "[]"))
                policy_role_ids = [role["id"] for role in policy_roles]
                is_enabled = role_proto.id in policy_role_ids
                is_visible = company_role_proto.id in policy_role_ids
            if policy is None:
                LOGGER.warning(f"{permission_name} has no matching role policy")
                continue
            yield authorization_pb2.RolePermissionResponse(
                permission=permission_name,
                is_enabled=is_enabled,
                is_visible=is_visible,
            )
