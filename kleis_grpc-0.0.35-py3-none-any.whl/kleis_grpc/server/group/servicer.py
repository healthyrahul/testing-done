from __future__ import annotations

import logging

from google.rpc import code_pb2, status_pb2
from grpc._server import _Context  # type: ignore
from grpc_status import rpc_status
from keycloak.exceptions import KeycloakPostError  # type: ignore

from kleis_grpc.protos.authorization import group_pb2, group_pb2_grpc, role_pb2
from kleis_grpc.server.exceptions import (
    CompanyNotFound,
    GroupNotFound,
    RoleNotFound,
)
from kleis_grpc.server.group.handlers import (
    assign_group_role,
    get_group_by_name,
)
from kleis_grpc.server.utils import keycloak_utils


LOGGER = logging.getLogger(__name__)


class GroupServicer(group_pb2_grpc.GroupServiceServicer):
    def createGroup(
        self,
        request: group_pb2.GroupRequest,
        context: _Context,
    ) -> group_pb2.Group:
        """Creates a group by name only. Addition of members or role has to happen
        after creation time.
        """
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            response = keycloak_admin.create_group(payload={"name": request.name})
            return group_pb2.Group(
                name=request.name,
                id=response,
            )
        except KeycloakPostError as e:
            if e.response_code == 409:
                status = status_pb2.Status(
                    code=code_pb2.ALREADY_EXISTS, message="Group already exists."
                )
                context.abort_with_status(rpc_status.to_status(status))
            else:
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN, message="Unknown KeycloakPostError occurred."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def getGroup(
        self,
        request: group_pb2.GroupRequest,
        context: _Context,
    ) -> group_pb2.Group:
        """Look up a group by name."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            group = get_group_by_name(name=request.name, keycloak_admin=keycloak_admin)
            if group == {}:
                raise GroupNotFound
            return group_pb2.Group(name=group["name"], id=group["id"])
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def listGroupMembers(
        self,
        request: group_pb2.GroupRequest,
        context: _Context,
    ) -> group_pb2.GroupMember:
        """Lookup a group by name and yield members (users)."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            group = get_group_by_name(name=request.name, keycloak_admin=keycloak_admin)
            if group == {}:
                raise GroupNotFound
            members = keycloak_admin.get_group_members(group_id=group["id"])
            for member in members:
                yield group_pb2.GroupMember(
                    username=member["username"],
                    user_id=member["id"],
                )
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def listGroupRoles(
        self,
        request: group_pb2.GroupRequest,
        context: _Context,
    ) -> role_pb2.Role:
        """Lookup a group by name and yield assigned roles."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            group = get_group_by_name(name=request.name, keycloak_admin=keycloak_admin)
            if group == {}:
                raise GroupNotFound

            # Collect roles for each possible client
            roles = []
            clients = keycloak_admin.get_clients()
            for client in clients:
                client_roles = keycloak_admin.get_group_client_roles(
                    group_id=group["id"], client_id=client["id"]
                )
                for client_role in client_roles:
                    roles.append(client_role)

            for role in roles:
                LOGGER.error(role)
                yield role_pb2.Role(
                    name=role["name"],
                    id=role["id"],
                    company_key=keycloak_admin.get_client(
                        client_id=role["containerId"]
                    )["clientId"],
                )
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def getFullGroup(
        self,
        request: group_pb2.GroupRequest,
        context: _Context,
    ) -> group_pb2.Group:
        """Get the full group object by name (including assigned members and roles)."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            group = get_group_by_name(name=request.name, keycloak_admin=keycloak_admin)
            if group == {}:
                raise GroupNotFound
            members = list(self.listGroupMembers(request=request, context=context))
            roles = list(self.listGroupRoles(request=request, context=context))
            return group_pb2.Group(
                name=group["name"],
                id=group["id"],
                roles=roles,
                members=members,
            )
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def deleteGroup(
        self,
        request: group_pb2.GroupRequest,
        context: _Context,
    ) -> group_pb2.Group:
        """Delete a group by name."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            group = get_group_by_name(name=request.name, keycloak_admin=keycloak_admin)
            if group == {}:
                raise GroupNotFound
            keycloak_admin.delete_group(group_id=group["id"])
            return group_pb2.Group()
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def assignGroupMember(
        self,
        request: group_pb2.GroupAndMemberRequest,
        context: _Context,
    ) -> group_pb2.Group:
        """Looks up group by name and assigns a member by username."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            group = get_group_by_name(
                name=request.group_name, keycloak_admin=keycloak_admin
            )
            if group == {}:
                raise GroupNotFound
            keycloak_admin.group_user_add(
                group_id=group["id"],
                user_id=keycloak_admin.get_user_id(request.username),
            )
            return group_pb2.Group()
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except KeycloakPostError as e:
            if e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Group member not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            else:
                LOGGER.exception(e)
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN, message="Unknown KeycloakPostError occurred."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def assignGroupRole(
        self,
        request: group_pb2.GroupAndRoleRequest,
        context: _Context,
    ) -> group_pb2.Group:
        """Looks up group by name and assigns a role by name and company_key."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            return assign_group_role(
                group_name=request.group_name,
                role_name=request.role_name,
                role_company_key=request.role_company_key,
                keycloak_admin=keycloak_admin,
            )
        except RoleNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Role not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except CompanyNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception:
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def removeGroupMember(
        self,
        request: group_pb2.GroupAndMemberRequest,
        context: _Context,
    ) -> group_pb2.Group:
        """Looks up a group by name and removes a member by username."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            group = get_group_by_name(
                name=request.group_name, keycloak_admin=keycloak_admin
            )
            if group == {}:
                raise GroupNotFound
            keycloak_admin.group_user_remove(
                group_id=group["id"],
                user_id=keycloak_admin.get_user_id(request.username),
            )
            return group_pb2.Group()
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except KeycloakPostError as e:
            if e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Group member not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            else:
                LOGGER.exception(e)
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN, message="Unknown KeycloakPostError occurred."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def removeGroupRole(
        self,
        request: group_pb2.GroupAndRoleRequest,
        context: _Context,
    ) -> group_pb2.Group:
        """Looks up a group by name and removes a role by name and company_key."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            group = get_group_by_name(
                name=request.group_name, keycloak_admin=keycloak_admin
            )
            if group == {}:
                raise GroupNotFound
            if not (
                client_id := keycloak_admin.get_client_id(request.role_company_key)
            ):
                LOGGER.error(
                    f"client_id not found for company_key {request.role_company_key}"
                )
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Company not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            # This does not actually delete the role; it just removes it from the group
            keycloak_admin.delete_group_client_roles(
                group_id=group["id"],
                client_id=client_id,
                roles=keycloak_admin.get_client_role(
                    client_id=client_id, role_name=request.role_name
                ),
            )
            return group_pb2.Group()
        except GroupNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Group not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except KeycloakPostError as e:
            if e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Role not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))
