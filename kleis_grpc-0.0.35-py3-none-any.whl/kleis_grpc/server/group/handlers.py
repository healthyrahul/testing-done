"""Handlers for group-related tasks.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from keycloak.exceptions import KeycloakPostError

from kleis_grpc.protos.authorization import group_pb2
from kleis_grpc.server.exceptions import (
    CompanyNotFound,
    GroupNotFound,
    RoleNotFound,
)


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


def get_group_by_name(
    name: str,
    keycloak_admin: KeycloakAdmin,
) -> dict:
    """Look up all groups and return the group that matches provided name."""
    groups = keycloak_admin.get_groups()
    return next((group for group in groups if group["name"] == name), {})


def assign_group_role(
    group_name: str,
    role_name: str,
    role_company_key: str,
    keycloak_admin: KeycloakAdmin,
) -> group_pb2.Group:
    try:
        group = get_group_by_name(name=group_name, keycloak_admin=keycloak_admin)
        if group == {}:
            raise GroupNotFound
        if not (client_id := keycloak_admin.get_client_id(role_company_key)):
            LOGGER.error(f"client_id not found for company_key {role_company_key}")
            raise CompanyNotFound
        keycloak_admin.assign_group_client_roles(
            group_id=group["id"],
            client_id=client_id,
            roles=keycloak_admin.get_client_role(
                client_id=client_id, role_name=role_name
            ),
        )
        return group_pb2.Group()
    except KeycloakPostError as e:
        if e.response_code == 404:
            raise RoleNotFound
    except Exception as e:
        LOGGER.exception(e)
        raise
