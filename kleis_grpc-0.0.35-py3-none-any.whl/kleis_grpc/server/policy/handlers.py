"""Handlers for policy-related tasks.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, List, Optional, Tuple

from requests import Response

from kleis_grpc.protos.authorization import policy_pb2, role_pb2
from kleis_grpc.server.exceptions import (
    CompanyNotFound,
    PolicyNotFound,
    RoleNotFound,
)
from kleis_grpc.server.role.handlers import get_role, get_role_by_id
from kleis_grpc.server.utils import keycloak_utils


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


def build_policy_proto_from_policy_dict(
    policy: dict,
    company_key: str,
    client_id: str,
    keycloak_admin: KeycloakAdmin,
) -> policy_pb2.Policy:
    # Let's do the get_clients() lookup once instead of for each role
    clients = keycloak_admin.get_clients()
    return policy_pb2.Policy(
        name=policy["name"],
        id=policy["id"],
        company_key=company_key,
        client_id=client_id,
        logic=policy["logic"],
        type=policy["type"],
        roles=[
            role_pb2.Role(
                id=role["id"],
                name=role["name"],
                company_key=(
                    next(
                        (
                            client["clientId"]
                            for client in clients
                            if client["id"] == role["containerId"]
                        ),
                        None,
                    )
                ),
            )
            for role in [
                get_role_by_id(
                    role_id=role["id"],
                    keycloak_admin=keycloak_admin,
                )
                for role in (
                    # For some reason we get the list of roles back as a string
                    # representation of a list[dict].
                    json.loads(policy["config"].get("roles", "[]"))
                )
            ]
        ],
    )


def yield_policy_protos_by_company(
    company_key: str, keycloak_admin: KeycloakAdmin
) -> policy_pb2.Policy:
    """Builds a friendly proto including nested Role protos. Very heavy function; use
    only when absolutely needed.
    """
    if not (client_id := keycloak_admin.get_client_id(company_key)):
        LOGGER.error(f"client_id not found for company_key {company_key}")
        raise PolicyNotFound
    policies = keycloak_admin.get_client_authz_policies(client_id=client_id)
    for policy in policies:
        yield build_policy_proto_from_policy_dict(
            policy=policy,
            company_key=company_key,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        )


def get_company_policies_with_role_id_member(
    policies_company_key: str,
    role_id: str,
    keycloak_admin: KeycloakAdmin,
) -> List[dict]:
    """Returns the native keycloak policy dict response if the found role ID is
    contained in the policy config.
    """
    client_id = keycloak_admin.get_client_id(policies_company_key)
    all_policies = keycloak_admin.get_client_authz_policies(client_id=client_id)
    policies_with_role = []
    for policy in all_policies:

        if role_id in [
            role["id"] for role in (json.loads(policy["config"].get("roles", "[]")))
        ]:
            policies_with_role.append(policy)
    return policies_with_role


def get_policy(
    name: str, company_key: str, keycloak_admin: KeycloakAdmin
) -> policy_pb2.Policy:
    if not (client_id := keycloak_admin.get_client_id(company_key)):
        LOGGER.error(f"client_id not found for company_key {company_key}")
        raise CompanyNotFound
    try:
        policy = get_policy_keycloak_dict_by_name(
            policy_name=name,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        )
        if policy is None:
            raise PolicyNotFound

        return build_policy_proto_from_policy_dict(
            policy=policy,
            company_key=company_key,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        )
    except Exception as e:
        LOGGER.exception(e)
        raise


def policy_url(
    keycloak_admin: KeycloakAdmin,
    client_id: str,
) -> str:
    return (
        f"{keycloak_admin.server_url}/admin/realms/"
        f"{keycloak_admin.connection.realm_name}/clients/"
        f"{client_id}/authz/resource-server/policy"
    )


def full_policy_url(
    keycloak_admin: KeycloakAdmin,
    client_id: str,
    policy_id: str,
    policy_type: str,
) -> str:
    return (
        policy_url(keycloak_admin=keycloak_admin, client_id=client_id)
        + f"/{policy_type}/{policy_id}"
    )


def update_policy_with_keycloak_dicts(
    keycloak_policy_dict: dict,
    updated_values_dict: dict,
    client_id: str,
    keycloak_admin: KeycloakAdmin,
) -> Tuple[Response, dict]:
    # Convert the bizarre string representation of roles into a proper list[dict]
    config = keycloak_policy_dict.pop("config")
    if "roles" in config.keys():
        keycloak_policy_dict["roles"] = json.loads(config["roles"])

    if "roles" in updated_values_dict.keys():
        entire_role_configs = updated_values_dict.pop("roles", [])
        # Strip roles down to just the IDs or keycloak throws a 500 error
        updated_values_dict["roles"] = [
            {"id": role["id"]} for role in entire_role_configs
        ]

    payload = keycloak_policy_dict | updated_values_dict
    try:
        response = keycloak_admin.connection.raw_put(
            path=full_policy_url(
                keycloak_admin=keycloak_admin,
                client_id=client_id,
                policy_id=payload["id"],
                policy_type=payload["type"],
            ),
            # keycloak wants a regular json object here, not a dict
            data=json.dumps(payload),
        )
        return response, payload
    except Exception as e:
        LOGGER.exception(e)
        raise


def add_role_id_to_policy_by_keycloak_dict(
    policy: dict, client_id: str, role_id: str, keycloak_admin: KeycloakAdmin
) -> Response:
    role_ids = [role["id"] for role in json.loads(policy["config"].get("roles", "[]"))]
    if role_id not in role_ids:
        role_ids.append(role_id)
    response, _ = update_policy_with_keycloak_dicts(
        keycloak_policy_dict=policy,
        updated_values_dict={"roles": [{"id": role_id} for role_id in role_ids]},
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )
    return response


def add_role_to_policy(
    policy_name: str,
    policy_company_key: str,
    role_name: str,
    role_company_key: Optional[str] = None,
    keycloak_admin: Optional[KeycloakAdmin] = None,
) -> Optional[Response]:
    if role_company_key is None:
        role_company_key = policy_company_key
    # I hate this. I'm doing it because I don't want to make a grpc endpoint for this
    # right now.
    if keycloak_admin is None:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
    client_id = keycloak_admin.get_client_id(client_id=policy_company_key)
    policy = get_policy_keycloak_dict_by_name(
        policy_name=policy_name, client_id=client_id, keycloak_admin=keycloak_admin
    )

    # Add the ID of the given role to the role list
    role_id = get_role(
        name=role_name, company_key=role_company_key, keycloak_admin=keycloak_admin
    ).id
    if role_id == "":
        return None
    return add_role_id_to_policy_by_keycloak_dict(
        policy=policy,
        client_id=client_id,
        role_id=role_id,
        keycloak_admin=keycloak_admin,
    )


def remove_role_id_from_policy_by_keycloak_dict(
    policy: dict, client_id: str, role_id: str, keycloak_admin: KeycloakAdmin
) -> Response:
    role_ids = [role["id"] for role in json.loads(policy["config"].get("roles", "[]"))]
    if role_id in role_ids:
        role_ids.remove(role_id)

    (response, _) = update_policy_with_keycloak_dicts(
        keycloak_policy_dict=policy,
        updated_values_dict={"roles": [{"id": role_id} for role_id in role_ids]},
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )
    return response


def remove_role_from_policy(
    policy_name: str,
    policy_company_key: str,
    role_name: str,
    role_company_key: Optional[str] = None,
    keycloak_admin: Optional[KeycloakAdmin] = None,
) -> Response:
    if role_company_key is None:
        role_company_key = policy_company_key
    # I hate this. I'm doing it because I don't want to make a grpc endpoint for this
    # right now.
    if keycloak_admin is None:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
    client_id = keycloak_admin.get_client_id(client_id=policy_company_key)
    policy = get_policy_keycloak_dict_by_name(
        policy_name=policy_name, client_id=client_id, keycloak_admin=keycloak_admin
    )

    # Remove the ID of the given role from the role list
    role_id = get_role(
        name=role_name, company_key=role_company_key, keycloak_admin=keycloak_admin
    ).id
    if role_id == "":
        raise RoleNotFound
    return remove_role_id_from_policy_by_keycloak_dict(
        policy=policy,
        client_id=client_id,
        role_id=role_id,
        keycloak_admin=keycloak_admin,
    )


def get_policy_keycloak_dict_by_name(
    policy_name: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[dict]:
    policies = keycloak_admin.get_client_authz_policies(client_id=client_id)
    policy = next(
        (policy for policy in policies if policy["name"] == policy_name),
        None,
    )
    return policy


def create_role_based_policy(
    name: str,
    logic: str,
    type: str,
    role_ids: List[str],
    client_id: str,
    keycloak_admin: KeycloakAdmin,
) -> dict:
    return keycloak_admin.create_client_authz_role_based_policy(
        client_id=client_id,
        payload={
            "name": name,
            "logic": logic,
            "type": type,
            "roles": [{"id": role_id} for role_id in role_ids],
        },
    )
