from __future__ import annotations

import logging

from google.rpc import code_pb2, status_pb2
from grpc._server import _Context  # type: ignore
from grpc_status import rpc_status
from keycloak.exceptions import KeycloakPostError  # type: ignore

from kleis_grpc.protos.authorization import (
    policy_pb2,
    policy_pb2_grpc,
    role_pb2,
)
from kleis_grpc.server.exceptions import PolicyNotFound
from kleis_grpc.server.policy.handlers import (
    create_role_based_policy,
    get_policy,
    update_policy_with_keycloak_dicts,
    yield_policy_protos_by_company,
)
from kleis_grpc.server.role.handlers import get_role, get_role_by_id
from kleis_grpc.server.utils import keycloak_utils


LOGGER = logging.getLogger(__name__)


class PolicyServicer(policy_pb2_grpc.PolicyServiceServicer):
    def createPolicy(
        self, request: policy_pb2.CreatePolicyRequest, context: _Context
    ) -> policy_pb2.Policy:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            if not (client_id := keycloak_admin.get_client_id(request.company_key)):
                LOGGER.error(
                    f"client_id not found for company_key {request.company_key}"
                )
            full_roles = [
                get_role(
                    name=role.name,
                    company_key=role.company_key,
                    keycloak_admin=keycloak_admin,
                )
                for role in request.roles
            ]
            response = create_role_based_policy(
                name=request.name,
                logic=request.logic,
                type=request.type,
                role_ids=[role.id for role in full_roles],
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )

            return policy_pb2.Policy(
                name=response["name"],
                id=response["id"],
                company_key=request.company_key,
                client_id=client_id,
                roles=[
                    role_pb2.Role(
                        id=role.id,
                        name=role.name,
                    )
                    for role in full_roles
                ],
            )
        except KeycloakPostError as e:
            if e.response_code == 409:
                status = status_pb2.Status(
                    code=code_pb2.ALREADY_EXISTS, message="Policy already exists."
                )
                context.abort_with_status(rpc_status.to_status(status))
            elif e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Company not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            else:
                LOGGER.error(e)
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN, message="Unknown KeycloakPostError."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def renamePolicy(
        self, request: policy_pb2.RenamePolicyRequest, context: _Context
    ) -> policy_pb2.Policy:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        client_id = keycloak_admin.get_client_id(request.company_key)
        # Get existing values so we don't zero these out by accident
        try:
            existing_policy = get_policy(
                name=request.name,
                company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )
        except PolicyNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Policy not found."
            )
            context.abort_with_status(rpc_status.to_status(status))

        policy_keycloak_dict = keycloak_admin.get_client_authz_policy(
            client_id=client_id,
            policy_id=existing_policy.id,
        )
        response, payload = update_policy_with_keycloak_dicts(
            keycloak_policy_dict=policy_keycloak_dict,
            updated_values_dict={"name": request.new_name},
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        )
        if response.ok:
            return policy_pb2.Policy(
                name=payload["name"],
                id=payload["id"],
                company_key=request.company_key,
                client_id=client_id,
                logic=payload["logic"],
                type=payload["type"],
                roles=[
                    role_pb2.Role(
                        id=role["id"],
                        name=get_role_by_id(
                            role_id=role["id"],
                            keycloak_admin=keycloak_admin,
                        )["name"],
                    )
                    for role in payload["roles"]
                ],
            )
        else:
            LOGGER.error(
                f"PUT request for policy/{policy_keycloak_dict['type']}/"
                f"{policy_keycloak_dict['id']} returned status_code "
                f"{response.status_code}"
            )
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def listPoliciesByCompany(
        self, request: policy_pb2.PoliciesByCompanyRequest, context: _Context
    ) -> policy_pb2.Policy:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        try:
            yield from yield_policy_protos_by_company(
                company_key=request.company_key, keycloak_admin=keycloak_admin
            )
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def getPolicy(
        self, request: policy_pb2.PolicyRequest, context: _Context
    ) -> policy_pb2.Policy:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        return get_policy(
            name=request.name,
            company_key=request.company_key,
            keycloak_admin=keycloak_admin,
        )

    def deletePolicy(
        self, request: policy_pb2.Policy, context: _Context
    ) -> policy_pb2.Policy:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        try:
            policy = get_policy(
                name=request.name,
                company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )
        except PolicyNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Policy not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        client_id = keycloak_admin.get_client_id(request.company_key)
        try:
            keycloak_admin.delete_client_authz_policy(
                client_id=client_id, policy_id=policy.id
            )
            return policy_pb2.Policy()
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))
