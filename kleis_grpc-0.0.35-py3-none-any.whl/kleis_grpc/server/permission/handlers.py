"""Handlers for permission-related tasks.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Optional

from keycloak.exceptions import KeycloakGetError

from kleis_grpc.protos.authorization import (
    permission_pb2,
    resource_pb2,
    scope_pb2,
)
from kleis_grpc.server.common.handlers import resource_server_endpoint
from kleis_grpc.server.exceptions import (
    CompanyNotFound,
    KeycloakPermissionFailed,
    PermissionNotFound,
)
from kleis_grpc.server.policy.handlers import (
    build_policy_proto_from_policy_dict,
)


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


def _get_resource_id_by_name(
    resource_name: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[str]:
    resources = keycloak_admin.get_client_authz_resources(client_id=client_id)
    resource = next(
        (resource for resource in resources if resource["name"] == resource_name),
        None,
    )
    if "_id" in resource.keys():
        return resource["_id"]
    else:
        return None


def _get_policy_id_by_name(
    policy_name: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[str]:
    policies = keycloak_admin.get_client_authz_policies(client_id=client_id)
    policy = next(
        (policy for policy in policies if policy["name"] == policy_name),
        None,
    )
    if "id" in policy.keys():
        return policy["id"]
    else:
        return None


def _get_scope_id_by_name(
    scope_name: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[str]:
    scopes = keycloak_admin.get_client_authz_scopes(client_id=client_id)
    scope = next((scope for scope in scopes if scope["name"] == scope_name), None)
    if "id" in scope.keys():
        return scope["id"]
    else:
        return None


def _get_resource_name_by_id(
    resource_id: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[str]:
    resources = keycloak_admin.get_client_authz_resources(client_id=client_id)
    resource = next(
        (resource for resource in resources if resource["_id"] == resource_id),
        None,
    )
    if "name" in resource.keys():
        return resource["name"]
    else:
        return None


def _get_scope_name_by_id(
    scope_id: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[str]:
    scopes = keycloak_admin.get_client_authz_scopes(client_id=client_id)
    scope = next((scope for scope in scopes if scope["id"] == scope_id), None)
    if "name" in scope.keys():
        return scope["name"]
    else:
        return None


def _get_policy_by_id(
    policy_id: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[str]:
    policies = keycloak_admin.get_client_authz_policies(client_id=client_id)
    policy = next(
        (policy for policy in policies if policy["id"] == policy_id),
        None,
    )
    if policy is not None:
        return policy
    else:
        return None


def _associated_policies_endpoint(
    keycloak_admin: KeycloakAdmin,
    client_id: str,
    permission_id: str,
) -> str:
    return str(
        resource_server_endpoint(keycloak_admin=keycloak_admin, client_id=client_id)
        + f"/policy/{permission_id}/associatedPolicies"
    )


def build_permission_payload_from_request(
    request: permission_pb2.Permission,
    client_id: str,
    keycloak_admin: KeycloakAdmin,
) -> dict:
    """Takes a Permission proto object and spins it into a payload you can use
    to POST or PUT to a permission endpoint.
    """
    # Build our payload by grabbing IDs for each component
    payload = {
        "name": request.name,
        "decisionStrategy": request.strategy,
        "resources": [],
        "scopes": [],
        "policies": [],
    }
    for resource in request.resources:
        if resource_id := _get_resource_id_by_name(
            resource_name=resource.name,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        ):
            payload["resources"].append(resource_id)
    for scope in request.scopes:
        if scope_id := _get_scope_id_by_name(
            scope_name=scope.name,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        ):
            payload["scopes"].append(scope_id)
    for policy in request.policies:
        if policy_id := _get_policy_id_by_name(
            policy_name=policy.name,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        ):
            payload["policies"].append(policy_id)
    return payload


def permission_endpoint(
    keycloak_admin: KeycloakAdmin,
    client_id: str,
) -> str:
    return str(
        resource_server_endpoint(keycloak_admin=keycloak_admin, client_id=client_id)
        + "/permission/scope"
    )


def create_keycloak_permission(
    request: permission_pb2.Permission, client_id: str, keycloak_admin: KeycloakAdmin
) -> permission_pb2.Permission:
    payload = build_permission_payload_from_request(
        request=request, client_id=client_id, keycloak_admin=keycloak_admin
    )

    try:
        response = keycloak_admin.connection.raw_post(
            path=permission_endpoint(
                keycloak_admin=keycloak_admin,
                client_id=client_id,
            ),
            # keycloak wants an actual json object here, we can't pass it the dict
            data=json.dumps(payload),
        )
    except Exception as e:
        LOGGER.exception(e)
        raise

    if response.ok:
        return build_permission_proto_from_dict(
            permission_dict=response.json(),
            company_key=request.company_key,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        )
    else:
        LOGGER.error(
            f"POST request to permission/scope returned status_code "
            f"{response.status_code}"
        )
        raise KeycloakPermissionFailed


def get_permission(
    name: str,
    company_key: str,
    keycloak_admin: KeycloakAdmin,
) -> permission_pb2.Permission:
    if not (client_id := keycloak_admin.get_client_id(company_key)):
        LOGGER.error(f"client_id not found for company_key {company_key}")
        raise CompanyNotFound

    existing_permission = gather_full_permission_dict_by_name(
        permission_name=name,
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )
    if existing_permission is None:
        raise PermissionNotFound
    return build_permission_proto_from_dict(
        permission_dict=existing_permission,
        company_key=company_key,
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )


def build_permission_proto_from_dict(
    permission_dict: dict,
    company_key: str,
    client_id: str,
    keycloak_admin: KeycloakAdmin,
) -> permission_pb2.Permission:
    """Takes a full permission dict, like you'd get from a POST response or from
    gather_full_permission_dict_by_name(), and hydrates a Permission proto with
    its contents.
    """
    return permission_pb2.Permission(
        name=permission_dict["name"],
        id=permission_dict["id"],
        company_key=company_key,
        client_id=client_id,
        strategy=permission_dict["decisionStrategy"],
        resources=[
            resource_pb2.Resource(
                name=_get_resource_name_by_id(
                    resource_id=resource_id,
                    client_id=client_id,
                    keycloak_admin=keycloak_admin,
                ),
                id=resource_id,
            )
            for resource_id in (
                permission_dict["resources"]
                if "resources" in permission_dict.keys()
                else []
            )
        ],
        scopes=[
            scope_pb2.Scope(
                name=_get_scope_name_by_id(
                    scope_id=scope_id,
                    client_id=client_id,
                    keycloak_admin=keycloak_admin,
                ),
                id=scope_id,
            )
            for scope_id in (
                permission_dict["scopes"] if "scopes" in permission_dict.keys() else []
            )
        ],
        policies=[
            build_policy_proto_from_policy_dict(
                policy=_get_policy_by_id(
                    policy_id=policy_id,
                    client_id=client_id,
                    keycloak_admin=keycloak_admin,
                ),
                company_key=company_key,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            for policy_id in (
                permission_dict["policies"]
                if "policies" in permission_dict.keys()
                else []
            )
        ],
    )


def _gather_supplemtary_permission_data(
    permission_id: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> dict:
    supplementary_data = {}
    # Individually fetch scopes/resources/policies
    supplementary_data["scopes"] = [
        # Yes, we have to refer to the permission as a policy to get this data
        scope["id"]
        for scope in keycloak_admin.get_client_authz_policy_scopes(
            client_id=client_id,
            policy_id=permission_id,
        )
    ]
    supplementary_data["resources"] = [
        resource["_id"]
        for resource in (
            keycloak_admin.get_client_authz_policy_resources(
                client_id=client_id,
                policy_id=permission_id,
            )
        )
    ]
    # There's no SDK function for getting the associated policies.
    policies_response = keycloak_admin.connection.raw_get(
        path=_associated_policies_endpoint(
            keycloak_admin=keycloak_admin,
            client_id=client_id,
            permission_id=permission_id,
        )
    )
    policies = policies_response.json()
    supplementary_data["policies"] = [policy["id"] for policy in policies]
    return supplementary_data


def gather_full_permission_dict_by_id(
    permission_id: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[dict]:
    """The keycloak SDK's permission functions don't return the full config for a
    scope-based permission. This function grabs the permission object (by id), then
    manually looks up the scopes, resources, and policies and adds them to the
    dict like you would see in the response from the POST endpoint.
    """
    # Get main permission object, which doesn't include the scopes/resources/or
    # policies.
    try:
        existing_permission = keycloak_admin.get_client_authz_scope_permission(
            client_id=client_id,
            scope_id=permission_id,  # this field is misnamed in the python-keycloak sdk
        )
    except KeycloakGetError:
        LOGGER.error(
            f"Cannot find permission permission_id {permission_id} for client_id "
            f"{client_id}"
        )
        return None

    supplementary_data = _gather_supplemtary_permission_data(
        permission_id=existing_permission["id"],
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )
    return existing_permission | supplementary_data


def gather_full_permission_dict_by_name(
    permission_name: str,
    client_id: str,
    keycloak_admin: KeycloakAdmin,
) -> Optional[dict]:
    """The keycloak SDK's permission functions don't return the full config for a
    scope-based permission. This function grabs the permission object (by name), then
    manually looks up the scopes, resources, and policies and adds them to the
    dict like you would see in the response from the POST endpoint.
    """
    # Get main permission object, which doesn't include the scopes/resources/or
    # policies. python-keycloak sdk doesn't include a function to return a permission
    # by name, so we have to iterate through them all.
    permissions = keycloak_admin.get_client_authz_permissions(client_id=client_id)
    existing_permission = next(
        (
            permission
            for permission in permissions
            if permission["name"] == permission_name
        ),
        None,
    )
    if existing_permission is None:
        return None
    supplementary_data = _gather_supplemtary_permission_data(
        permission_id=existing_permission["id"],
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )
    return existing_permission | supplementary_data
