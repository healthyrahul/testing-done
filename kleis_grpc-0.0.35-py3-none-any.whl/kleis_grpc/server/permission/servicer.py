from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from google.rpc import code_pb2, status_pb2
from grpc._server import _Context  # type: ignore
from grpc_status import rpc_status
from keycloak.exceptions import (  # type: ignore; KeycloakPostError,
    KeycloakPutError,
)

from kleis_grpc.protos.authorization import permission_pb2, permission_pb2_grpc
from kleis_grpc.server.permission.handlers import (
    build_permission_proto_from_dict,
    gather_full_permission_dict_by_name,
    get_permission,
    permission_endpoint,
)
from kleis_grpc.server.resource.handlers import get_resource_by_name
from kleis_grpc.server.utils import keycloak_utils


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


class PermissionServicer(permission_pb2_grpc.PermissionServiceServicer):
    def _permission_id_endpoint(
        self,
        keycloak_admin: KeycloakAdmin,
        client_id: str,
        permission_id: str,
    ) -> str:
        return str(
            permission_endpoint(keycloak_admin=keycloak_admin, client_id=client_id)
            + f"/{permission_id}"
        )

    def renamePermission(
        self, request: permission_pb2.RenamePermissionRequest, context: _Context
    ) -> permission_pb2.Permission:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))

        # Get existing values so we don't zero these out by accident
        permission = gather_full_permission_dict_by_name(
            permission_name=request.name,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        )
        if permission is None:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Permission not found."
            )
            context.abort_with_status(rpc_status.to_status(status))

        permission["name"] = request.new_name
        try:
            keycloak_admin.update_client_authz_scope_permission(
                payload=permission, client_id=client_id, scope_id=permission["id"]
            )
            return build_permission_proto_from_dict(
                permission_dict=permission,
                company_key=request.company_key,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
        except (Exception, KeycloakPutError) as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def listPermissionsByCompany(
        self, request: permission_pb2.PermissionsByCompanyRequest, context: _Context
    ) -> permission_pb2.Permission:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        permission_names = [
            permission["name"]
            for permission in (
                keycloak_admin.get_client_authz_permissions(client_id=client_id)
            )
        ]
        # Now that we have permission names, we need to iterate through and build the
        # full object for each of them.
        for permission_name in permission_names:
            full_permission = gather_full_permission_dict_by_name(
                permission_name=permission_name,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            yield build_permission_proto_from_dict(
                permission_dict=full_permission,
                company_key=request.company_key,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )

    def listPermissionsByResource(
        self, request: permission_pb2.PermissionsByResourceRequest, context: _Context
    ) -> permission_pb2.Permission:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        permission_names = [
            permission["name"]
            for permission in (
                keycloak_admin.get_client_authz_permissions(client_id=client_id)
            )
        ]
        # Now that we have permission names, we need to iterate through and build the
        # full object for each of them. Only then will we know which resources are tied
        # to which permission, so that we can filter them.
        resource = get_resource_by_name(
            resource_name=request.resource_name,
            client_id=client_id,
            keycloak_admin=keycloak_admin,
        )
        for permission_name in permission_names:
            full_permission = gather_full_permission_dict_by_name(
                permission_name=permission_name,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            if resource["_id"] in full_permission.get("resources", []):
                yield build_permission_proto_from_dict(
                    permission_dict=full_permission,
                    company_key=request.company_key,
                    client_id=client_id,
                    keycloak_admin=keycloak_admin,
                )

    def getPermission(
        self, request: permission_pb2.PermissionRequest, context: _Context
    ) -> permission_pb2.Permission:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        return get_permission(
            name=request.name,
            company_key=request.company_key,
            keycloak_admin=keycloak_admin,
        )

    def deletePermission(
        self, request: permission_pb2.PermissionRequest, context: _Context
    ) -> permission_pb2.Permission:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            permission = get_permission(
                name=request.name, company_key=request.company_key
            )
            response = keycloak_admin.connection.raw_delete(
                path=self._permission_id_endpoint(
                    keycloak_admin=keycloak_admin,
                    client_id=client_id,
                    permission_id=permission.id,
                )
            )
            if response.ok:
                return permission_pb2.Permission()
            if response.status_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Permission not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            else:
                LOGGER.error(
                    "DELETE request for permission/scope/%s returned status_code %s",
                    permission.id,
                    response.status_code,
                )
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN, message="Unknown response from endpoint."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))
