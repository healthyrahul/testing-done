"""Implementations of User Related gRPC Servicers."""
# pylint: disable=no-member
import logging

import jwt
import grpc
from grpc._server import _Context  # type: ignore
from jwt.exceptions import DecodeError
from keycloak.exceptions import (  # type: ignore
    KeycloakConnectionError,
    KeycloakPostError,
)

from kleis_grpc.protos.authentication import (
    token_manager_pb2,
    token_manager_pb2_grpc,
    user_pb2,
)
from kleis_grpc.server.settings import (
    KEYCLOAK_JWT_ALGORITHMS,
    KEYCLOAK_JWT_AUDIENCE,
    PUB_KEY_TEMPLATE,
)
from kleis_grpc.server.utils import keycloak_utils
from kleis_grpc.server.utils.exception_handling import handle_unknown_exception


LOGGER = logging.getLogger(__name__)

INVALID_GRANT = "invalid_grant"


class TokenManagerServicer(
    token_manager_pb2_grpc.TokenManagerServicer
):  # pylint: disable=too-few-public-methods
    """Implementation of the UsersServicer gRPC codestub."""

    def renewTokens(
        self, request: token_manager_pb2.RenewTokensRequest, context: _Context
    ) -> token_manager_pb2.RenewTokensResponse:
        """Exchange a refresh token for a fresh JWT pair."""
        response = token_manager_pb2.RenewTokensResponse()
        try:
            keycloak_client = keycloak_utils.get_keycloak_client()
            refresh_response = keycloak_client.refresh_token(request.refresh_token)
            access_token = refresh_response.get("access_token")
            refresh_token = refresh_response.get("refresh_token")
            response.access_token = access_token
            response.refresh_token = refresh_token
        except (
            KeycloakConnectionError,
            KeycloakPostError,
        ) as err:
            if INVALID_GRANT in err.error_message.decode():
                LOGGER.error("Token Invalid! %s", request.access_token)
                context.set_code(grpc.StatusCode.UNAUTHENTICATED)
                context.set_details("Token Invalid!")
            else:
                LOGGER.exception("Unable to connect to keycloak.")
                context.set_code(grpc.StatusCode.UNAVAILABLE)
                context.set_details("Service is unavailable at this time. Please try later.")
        except Exception:  # pylint: disable=broad-exception-caught
            handle_unknown_exception(context)
        return response

    def verifyToken(
        self, request: token_manager_pb2.VerifyTokenRequest, context: _Context
    ) -> user_pb2.KleisUserResponse:
        """Verify a Keycloak issued access token and return user information."""
        response = user_pb2.KleisUserResponse()
        try:
            keycloak_client = keycloak_utils.get_keycloak_client()
            pub_key = PUB_KEY_TEMPLATE.format(key=keycloak_client.public_key())
            decoded_token = jwt.decode(
                request.access_token,
                key=pub_key,
                algorithms=KEYCLOAK_JWT_ALGORITHMS,
                audience=KEYCLOAK_JWT_AUDIENCE,
            )
            response.email = decoded_token.get('preferred_username')
            response.first_name = decoded_token.get('given_name')
            response.last_name = decoded_token.get('family_name')
            # Only active users can be granted tokens.
            response.is_active = True
        except DecodeError:
            LOGGER.error("Token Invalid! %s", request.access_token)
            context.set_code(grpc.StatusCode.UNAUTHENTICATED)
            context.set_details("Token Invalid!")
        except Exception:  # pylint: disable=broad-exception-caught
            handle_unknown_exception(context)
        return response
