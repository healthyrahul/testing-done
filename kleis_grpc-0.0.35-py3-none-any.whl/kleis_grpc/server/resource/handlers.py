"""Handlers for keycloak resource-related tasks.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""
from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, List, Optional

from kleis_grpc.protos.authorization import resource_pb2
from kleis_grpc.server.exceptions import ResourceFailed, ResourceNotFound


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


def get_resource_by_name(
    resource_name: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[dict]:
    resources = keycloak_admin.get_client_authz_resources(client_id=client_id)
    resource = next(
        (resource for resource in resources if resource["name"] == resource_name),
        None,
    )
    return resource


def create_resource(
    name: str,
    friendly_name: str,
    category: str,
    scopes: List[str],
    client_id: str,
    keycloak_admin: KeycloakAdmin,
) -> dict:
    return keycloak_admin.create_client_authz_resource(
        client_id=client_id,
        payload={
            "name": name,
            "displayName": friendly_name,
            "type": category,
            "scopes": [{"name": scope} for scope in scopes],
        },
    )


def build_resource_url(
    keycloak_admin: KeycloakAdmin, client_id: str, resource_id: str
) -> str:
    return (
        f"{keycloak_admin.server_url}/admin/realms/"
        f"{keycloak_admin.connection.realm_name}/clients/"
        f"{client_id}/authz/resource-server/resource/{resource_id}"
    )


def update_resource(
    name: str,
    company_key: str,
    client_id: str,
    updated_values: dict,
    keycloak_admin: KeycloakAdmin,
) -> resource_pb2.Resource:
    # Get existing values so we don't zero these out by accident later
    existing_resource = get_resource_by_name(
        resource_name=name,
        client_id=client_id,
        keycloak_admin=keycloak_admin,
    )
    if existing_resource is None:
        raise ResourceNotFound

    # Build payload based on existing resource so we don't drop anything. Items
    # left out will be zeroed out by keycloak.
    payload = {}

    if name := updated_values["name"] if "name" in updated_values.keys() else False:
        payload["name"] = name
    else:
        payload["name"] = existing_resource["name"]
    payload["_id"] = existing_resource["_id"]
    payload["displayName"] = (
        existing_resource["displayName"]
        if ("displayName" in existing_resource.keys())
        else ""
    )
    payload["icon_uri"] = (
        existing_resource["icon_uri"]
        if ("icon_uri" in existing_resource.keys())
        else ""
    )
    payload["type"] = existing_resource["type"]
    # Lucky for us, the keycloak API can take just strings of scope names instead
    # of entire scope objects
    if "scopes" in updated_values.keys():
        payload["scopes"] = updated_values["scopes"]
    else:
        # An existing scope will return full scope objects, but we only need the
        # name.
        payload["scopes"] = (
            [scope["name"] for scope in existing_resource["scopes"]]
            if "scopes" in existing_resource.keys()
            else []
        )

    # python-keycloak does not currently have a function for updating client authz
    # resources, so we have to do a raw PUT here.
    response = keycloak_admin.connection.raw_put(
        path=build_resource_url(
            keycloak_admin=keycloak_admin,
            client_id=client_id,
            resource_id=existing_resource["_id"],
        ),
        data=json.dumps(payload),
    )
    if response.status_code == 204:
        return resource_pb2.Resource(
            name=payload["name"],
            id=payload["_id"],
            company_key=company_key,
            client_id=client_id,
            category=payload["type"],
            friendly_name=payload["displayName"],
            scopes=payload["scopes"] if "scopes" in payload.keys() else [],
        )
    else:
        LOGGER.error(
            f"PUT request for resource/{payload['_id']} returned status_code "
            f"{response.status_code}"
        )
        raise ResourceFailed
