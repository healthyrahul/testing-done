from __future__ import annotations

import logging

import grpc
from google.rpc import code_pb2, status_pb2
from grpc._server import _Context  # type: ignore
from grpc_status import rpc_status
from keycloak.exceptions import KeycloakPostError  # type: ignore

from kleis_grpc.protos.authorization import resource_pb2, resource_pb2_grpc
from kleis_grpc.server.exceptions import ResourceFailed, ResourceNotFound
from kleis_grpc.server.resource.handlers import (
    build_resource_url,
    create_resource,
    get_resource_by_name,
    update_resource,
)
from kleis_grpc.server.utils import keycloak_utils


LOGGER = logging.getLogger(__name__)


class ResourceServicer(resource_pb2_grpc.ResourceServiceServicer):
    def createResource(
        self, request: resource_pb2.CreateResourceRequest, context: _Context
    ) -> resource_pb2.Resource:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            if not (client_id := keycloak_admin.get_client_id(request.company_key)):
                LOGGER.error(
                    f"client_id not found for company_key {request.company_key}"
                )
            response = create_resource(
                name=request.name,
                friendly_name=request.friendly_name,
                category=request.category,
                scopes=request.scopes,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            return resource_pb2.Resource(
                name=response["name"],
                id=response["_id"],
                company_key=request.company_key,
                client_id=client_id,
                category=request.category,
                friendly_name=request.friendly_name,
                scopes=[
                    scope["name"]
                    for scope in (
                        response["scopes"] if "scopes" in response.keys() else []
                    )
                ],
            )
        except KeycloakPostError as e:
            if e.response_code == 409:
                status = status_pb2.Status(
                    code=code_pb2.ALREADY_EXISTS, message="Resource already exists."
                )
            elif e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Company not found."
                )
            else:
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN, message="Unknown KeycloakPostError occurred."
                )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

    def renameResource(
        self, request: resource_pb2.RenameResourceRequest, context: _Context
    ) -> resource_pb2.Resource:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            return update_resource(
                name=request.name,
                company_key=request.company_key,
                client_id=client_id,
                updated_values={"name": request.new_name},
                keycloak_admin=keycloak_admin,
            )
        except ResourceNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Resource not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except ResourceFailed:
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Resource update failed."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception:
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

    def listResourcesByCompany(
        self, request: resource_pb2.ResourcesByCompanyRequest, context: _Context
    ) -> resource_pb2.Resource:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            resources = keycloak_admin.get_client_authz_resources(client_id=client_id)
            for resource in resources:
                yield resource_pb2.Resource(
                    name=resource["name"],
                    id=resource["_id"],
                    company_key=request.company_key,
                    client_id=client_id,
                    category=resource["type"],
                    friendly_name=resource["displayName"],
                    scopes=[
                        scope["name"]
                        for scope in (
                            resource["scopes"] if ("scopes" in resource.keys()) else []
                        )
                    ],
                )
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

    def deleteResource(
        self, request: resource_pb2.ResourceRequest, context: _Context
    ) -> resource_pb2.Resource:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            resource = get_resource_by_name(
                resource_name=request.name,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            if resource is None:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Resource not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            response = keycloak_admin.connection.raw_delete(
                path=build_resource_url(
                    keycloak_admin=keycloak_admin,
                    client_id=client_id,
                    resource_id=resource["_id"],
                )
            )
            if response.ok:
                return resource_pb2.Resource()
            elif response.status_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Resource not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            else:
                LOGGER.error(
                    f"DELETE request for resource/{resource['_id']} returned "
                    f"status_code {response.status_code}"
                )
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN,
                    message="Unknown error from resource endpoint.",
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

    def getResource(
        self, request: resource_pb2.ResourceRequest, context: _Context
    ) -> resource_pb2.Resource:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            resource = get_resource_by_name(
                resource_name=request.name,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            if resource is None:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Resource not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            return resource_pb2.Resource(
                name=resource["name"],
                id=resource["_id"],
                company_key=request.company_key,
                client_id=client_id,
                category=resource["type"],
                friendly_name=resource["displayName"],
                scopes=[
                    scope["name"]
                    for scope in (
                        resource["scopes"] if "scopes" in resource.keys() else []
                    )
                ],
            )
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )
