"""Handlers for role-related tasks.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, List

from keycloak.exceptions import (  # type: ignore
    KeycloakGetError,
    KeycloakPutError,
)

from kleis_grpc.protos.authorization import role_pb2
from kleis_grpc.server.exceptions import CompanyNotFound, RoleNotFound


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


def get_role_by_id(role_id: str, keycloak_admin: KeycloakAdmin) -> dict:
    response = keycloak_admin.connection.raw_get(
        path=(
            f"{keycloak_admin.server_url}/admin/realms/"
            f"{keycloak_admin.connection.realm_name}/roles-by-id/{role_id}"
        )
    )
    if not response.ok:
        raise Exception(
            f"Unable to lookup role. Recieved response code {response.response_code} "
            "from roles-by-id endpoint."
        )
    return response.json()


def client_role_mapping_url(
    keycloak_admin: KeycloakAdmin,
    client_id: str,
    user_id: str,
) -> str:
    return (
        f"{keycloak_admin.server_url}/admin/realms/"
        f"{keycloak_admin.connection.realm_name}/users/"
        f"{user_id}/role-mappings/clients/{client_id}"
    )


def update_propagated_role_list(
    role_name: str,
    company_key: str,
    propagated_companies: List[str],
    keycloak_admin: KeycloakAdmin,
) -> role_pb2.Role:
    """Take only the propagated_companies portion of the Role proto and use it to
    update the attribute on the Role.
    """
    if not (client_id := keycloak_admin.get_client_id(company_key)):
        LOGGER.error(f"client_id not found for company_key {company_key}")
        raise CompanyNotFound
    try:
        # Build payload based on existing role so we don't drop anything. Items
        # left out will be zeroed out by keycloak.
        role = keycloak_admin.get_client_role(client_id=client_id, role_name=role_name)
        role["attributes"]["propagated_companies"] = list(propagated_companies)

        keycloak_admin.update_client_role(
            client_role_id=client_id, role_name=role_name, payload=role
        )

    except KeycloakGetError as e:
        if e.response_code == 404:
            raise RoleNotFound
    except KeycloakPutError as e:
        if e.response_code == 404:
            raise CompanyNotFound
        elif e.response_code == 405:
            raise RoleNotFound
    except Exception as e:
        LOGGER.exception(e)
        raise

    return role_pb2.Role(
        name=role["name"],
        company_key=company_key,
        description=(role.get("description", None)),
        propagated_companies=propagated_companies,
    )


def get_role(
    name: str, company_key: str, keycloak_admin: KeycloakAdmin
) -> role_pb2.Role:
    if not (client_id := keycloak_admin.get_client_id(company_key)):
        LOGGER.error(f"client_id not found for company_key {company_key}")
        raise CompanyNotFound
    try:
        role = keycloak_admin.get_client_role(client_id=client_id, role_name=name)
        return role_pb2.Role(
            name=role["name"],
            id=role["id"],
            company_key=keycloak_admin.get_client(client_id=role["containerId"])[
                "clientId"
            ],
            client_id=role["containerId"],
            description=(role.get("description", None)),
            propagated_companies=(role["attributes"].get("propagated_companies", [])),
        )
    except KeycloakGetError as e:
        if e.response_code == 404:
            raise RoleNotFound
    except Exception as e:
        LOGGER.exception(e)
        raise


def create_role(
    name: str, description: str, client_id: str, keycloak_admin: KeycloakAdmin
):
    return keycloak_admin.create_client_role(
        client_role_id=client_id,
        payload={
            "name": name,
            "description": description,
            "clientRole": True,
        },
    )
