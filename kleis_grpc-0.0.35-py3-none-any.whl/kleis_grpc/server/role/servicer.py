from __future__ import annotations

import json

# pylint: disable=no-member
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING, List

import grpc
from google.rpc import code_pb2, status_pb2
from grpc._server import _Context  # type: ignore
from grpc_status import rpc_status
from keycloak.exceptions import (  # type: ignore
    KeycloakGetError,
    KeycloakPostError,
    KeycloakPutError,
)

from kleis_grpc.protos.authorization import role_pb2, role_pb2_grpc
from kleis_grpc.server.authorization.handlers import (
    propagate_existing_role_permissions,
    unpropagate_existing_role_permissions,
)
from kleis_grpc.server.exceptions import RoleNotFound
from kleis_grpc.server.role.handlers import (
    client_role_mapping_url,
    create_role,
    get_role,
    update_propagated_role_list,
)
from kleis_grpc.server.utils import keycloak_utils


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


class RoleServicer(role_pb2_grpc.RoleServiceServicer):
    def createRole(
        self, request: role_pb2.CreateRoleRequest, context: _Context
    ) -> role_pb2.Role:
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            if not (client_id := keycloak_admin.get_client_id(request.company_key)):
                LOGGER.error(
                    f"client_id not found for company_key {request.company_key}"
                )
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Company not found."
                )
                context.abort_with_status(rpc_status.to_status(status))

            create_role(
                name=request.name,
                description=request.description,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            return role_pb2.Role(name=request.name)

        except KeycloakPostError as e:
            if e.response_code == 409:
                status = status_pb2.Status(
                    code=code_pb2.ALREADY_EXISTS, message="Role already exists."
                )
            elif e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Company not found."
                )
            else:
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN,
                    message="Unknown error from Keycloak endpoint.",
                )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

    def updateRole(
        self, request: role_pb2.UpdateRoleRequest, context: _Context
    ) -> role_pb2.Role:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        # Get existing values so we don't zero these out by accident later
        try:
            existing_role = keycloak_admin.get_client_role(
                client_id=client_id, role_name=request.name
            )
            # Build payload based on existing role so we don't drop anything. Items
            # left out will be zeroed out by keycloak.
            updated_values = {}
            if request.new_name != "":
                updated_values["name"] = request.new_name
            if request.new_description != "":
                updated_values["description"] = request.new_description
            payload = existing_role | updated_values
            keycloak_admin.update_client_role(
                client_role_id=client_id, role_name=request.name, payload=payload
            )

        except KeycloakGetError as e:
            if e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Role not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except KeycloakPutError as e:
            if e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Company not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
            elif e.response_code == 405:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Role not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

        return role_pb2.Role(
            name=payload["name"],
            company_key=request.company_key,
            description=(
                payload["description"] if "description" in payload.keys() else ""
            ),
        )

    def listAssignedCompanyRolesByUser(
        self, request: role_pb2.AssignedCompanyRolesByUserRequest, context: _Context
    ) -> role_pb2.Role:
        keycloak_admin = keycloak_utils.get_keycloak_admin()

        if not (user_id := keycloak_admin.get_user_id(request.username)):
            LOGGER.error(f"user_id not found for username {request.username}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="User not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))

        client_roles_assigned = keycloak_admin.get_client_roles_of_user(
            user_id=user_id, client_id=client_id
        )

        for role in client_roles_assigned:
            yield role_pb2.Role(
                name=role["name"],
                id=role["id"],
                company_key=keycloak_admin.get_client(client_id=role["containerId"])[
                    "clientId"
                ],
                client_id=role["containerId"],
                description=(
                    role["description"] if "description" in role.keys() else ""
                ),
            )

    def listRolesByCompany(
        self, request: role_pb2.RolesByCompanyRequest, context: _Context
    ) -> role_pb2.Role:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            client_roles = keycloak_admin.get_client_roles(client_id=client_id)
        except (KeycloakGetError, Exception) as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

        for role in client_roles:
            yield role_pb2.Role(
                name=role["name"],
                id=role["id"],
                company_key=keycloak_admin.get_client(client_id=role["containerId"])[
                    "clientId"
                ],
                client_id=role["containerId"],
                description=(
                    role["description"] if "description" in role.keys() else ""
                ),
            )

    def listAssignedUsersByRole(
        self, request: role_pb2.RoleRequest, context: _Context
    ) -> role_pb2.UserResponse:
        if not request.name:
            raise ValueError("name is required.")

        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            role = keycloak_admin.get_client_role(
                client_id=client_id, role_name=request.name
            )
        except KeycloakGetError as e:
            if e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Role not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

        members = keycloak_admin.get_client_role_members(
            client_id=client_id, role_name=role["name"]
        )
        for member in members:
            yield role_pb2.UserResponse(
                username=member["username"],
                user_id=member["id"],
            )

    def deleteRole(
        self, request: role_pb2.RoleRequest, context: _Context
    ) -> role_pb2.Role:
        if not request.name:
            raise ValueError("name is required.")

        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            role = keycloak_admin.get_client_role(
                client_id=client_id, role_name=request.name
            )
            keycloak_admin.delete_client_role(
                client_role_id=client_id, role_name=role["name"]
            )
        except KeycloakGetError as e:
            if e.response_code == 404:
                status = status_pb2.Status(
                    code=code_pb2.NOT_FOUND, message="Role not found."
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )
        return role_pb2.Role()

    def getRole(
        self, request: role_pb2.RoleRequest, context: _Context
    ) -> role_pb2.Role:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        return get_role(
            name=request.name,
            company_key=request.company_key,
            keycloak_admin=keycloak_admin,
        )

    def _propagate_existing_permissions_to_multi_companies(
        self,
        role_id: str,
        role_company_key: str,
        propagated_company_keys: List[str],
        keycloak_admin: KeycloakAdmin,
    ) -> None:
        """Threaded worker for propagating existing permissions per company_key."""

        def worker(company_key: str):
            if not (client_id := keycloak_admin.get_client_id(company_key)):
                LOGGER.error(f"client_id not found for company_key {company_key}")
            else:
                propagate_existing_role_permissions(
                    role_id=role_id,
                    role_company_key=role_company_key,
                    client_id=client_id,
                    propagated_company_key=company_key,
                    keycloak_admin=keycloak_admin,
                )
            return None

        num_workers = 10  # This is the default max poolsize of HTTPAdapter
        exceptions: list[Exception] = []
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = (
                executor.submit(worker, company_key)
                for company_key in propagated_company_keys
            )
            for future in as_completed(futures):
                if exception := future.exception():
                    exceptions.append(exception)
        if exceptions:
            raise ExceptionGroup(
                "Propagating existing permissions failed to some propagated companies.",
                exceptions,
            )
        return None

    def addPropagatedCompaniesToRole(
        self, request: role_pb2.PropagateRoleRequest, context: _Context
    ) -> role_pb2.Role:
        keycloak_admin = keycloak_utils.get_keycloak_admin()

        role = get_role(
            name=request.role_name,
            company_key=request.role_company_key,
            keycloak_admin=keycloak_admin,
        )
        for company_key in request.propagated_company_keys:
            if company_key not in role.propagated_companies:
                role.propagated_companies.append(company_key)
        updated_role_response = update_propagated_role_list(
            role_name=role.name,
            company_key=role.company_key,
            propagated_companies=role.propagated_companies,
            keycloak_admin=keycloak_admin,
        )

        self._propagate_existing_permissions_to_multi_companies(
            role_id=role.id,
            role_company_key=role.company_key,
            propagated_company_keys=request.propagated_company_keys,
            keycloak_admin=keycloak_admin,
        )

        return updated_role_response

    def _unpropagate_existing_permissions_from_multi_companies(
        self,
        role_id: str,
        propagated_company_keys: List[str],
        keycloak_admin: KeycloakAdmin,
    ) -> None:
        """Threaded worker for unpropagating a set of permissions per company_key."""

        def worker(company_key: str) -> None:
            if not (client_id := keycloak_admin.get_client_id(company_key)):
                LOGGER.error(f"client_id not found for company_key {company_key}")
            else:
                unpropagate_existing_role_permissions(
                    role_id=role_id,
                    client_id=client_id,
                    propagated_company_key=company_key,
                    keycloak_admin=keycloak_admin,
                )
            return None

        num_workers = 10  # This is the default max poolsize of HTTPAdapter
        exceptions: list[Exception] = []
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = (
                executor.submit(worker, company_key)
                for company_key in propagated_company_keys
            )
            for future in as_completed(futures):
                if exception := future.exception():
                    exceptions.append(exception)
        if exceptions:
            raise ExceptionGroup(
                "Propagating existing permissions failed to some propagated companies.",
                exceptions,
            )
        return None

    def removePropagatedCompaniesFromRole(
        self, request: role_pb2.PropagateRoleRequest, context: _Context
    ) -> role_pb2.Role:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        role = get_role(
            name=request.role_name,
            company_key=request.role_company_key,
            keycloak_admin=keycloak_admin,
        )
        for company_key in request.propagated_company_keys:
            if company_key in role.propagated_companies:
                role.propagated_companies.remove(company_key)
        updated_role_response = update_propagated_role_list(
            role_name=role.name,
            company_key=role.company_key,
            propagated_companies=role.propagated_companies,
            keycloak_admin=keycloak_admin,
        )

        self._unpropagate_existing_permissions_from_multi_companies(
            role_id=role.id,
            propagated_company_keys=request.propagated_company_keys,
            keycloak_admin=keycloak_admin,
        )

        return updated_role_response

    def setPropagatedCompanies(
        self, request: role_pb2.PropagateRoleRequest, context: _Context
    ) -> role_pb2.Role:
        """Takes a list of company_keys, and uses a diff from the current values to
        propagate to new companies and unpropagate from removed companies.
        """
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        role = get_role(
            name=request.role_name,
            company_key=request.role_company_key,
            keycloak_admin=keycloak_admin,
        )
        previous_companies = list(role.propagated_companies)
        added_companies = []
        removed_companies = []
        for company_key in request.propagated_company_keys:
            if company_key not in role.propagated_companies:
                role.propagated_companies.append(company_key)
                added_companies.append(company_key)
        for company_key in previous_companies:
            if company_key not in request.propagated_company_keys:
                role.propagated_companies.remove(company_key)
                removed_companies.append(company_key)
        updated_role_response = update_propagated_role_list(
            role_name=role.name,
            company_key=role.company_key,
            propagated_companies=role.propagated_companies,
            keycloak_admin=keycloak_admin,
        )

        self._propagate_existing_permissions_to_multi_companies(
            role_id=role.id,
            role_company_key=role.company_key,
            propagated_company_keys=added_companies,
            keycloak_admin=keycloak_admin,
        )
        self._unpropagate_existing_permissions_from_multi_companies(
            role_id=role.id,
            propagated_company_keys=removed_companies,
            keycloak_admin=keycloak_admin,
        )
        return updated_role_response

    def addRoleToUser(
        self, request: role_pb2.UserRoleRequest, context: _Context
    ) -> role_pb2.UserResponse:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not keycloak_admin.get_client_id(request.role_company_key):
            LOGGER.error(
                f"client_id not found for company_key {request.role_company_key}"
            )
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        if not (user_id := keycloak_admin.get_user_id(request.username)):
            LOGGER.error(f"user_id not found for username {request.username}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="User not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            role = get_role(
                name=request.role_name,
                company_key=request.role_company_key,
                keycloak_admin=keycloak_admin,
            )
            endpoint = client_role_mapping_url(
                keycloak_admin=keycloak_admin, client_id=role.client_id, user_id=user_id
            )
            response = keycloak_admin.connection.raw_post(
                path=endpoint,
                # keycloak wants regular json object here
                # It also needs a bare minimum of id and name or it will throw a 404.
                data=json.dumps([{"id": role.id, "name": role.name}]),
            )
            if response.ok:
                return role_pb2.UserResponse()
            else:
                LOGGER.error(
                    f"POST request to {endpoint} returned status_code "
                    + str(response.status_code)
                )
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN,
                    message="Unknown response from Keycloak endpoint.",
                )
                context.abort_with_status(rpc_status.to_status(status))
        except RoleNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Role not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )

    def removeRoleFromUser(
        self, request: role_pb2.UserRoleRequest, context: _Context
    ) -> role_pb2.UserResponse:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not keycloak_admin.get_client_id(request.role_company_key):
            LOGGER.error(
                f"client_id not found for company_key {request.role_company_key}"
            )
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        if not (user_id := keycloak_admin.get_user_id(request.username)):
            LOGGER.error(f"user_id not found for username {request.username}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="User not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        try:
            role = get_role(
                name=request.role_name,
                company_key=request.role_company_key,
                keycloak_admin=keycloak_admin,
            )
            endpoint = client_role_mapping_url(
                keycloak_admin=keycloak_admin, client_id=role.client_id, user_id=user_id
            )
            response = keycloak_admin.connection.raw_delete(
                path=endpoint,
                # keycloak wants regular json object here
                # It also needs a bare minimum of id and name or it will throw a 404.
                data=json.dumps([{"id": role.id, "name": role.name}]),
            )
            if response.ok:
                return role_pb2.UserResponse()
            else:
                LOGGER.error(
                    f"DELETE request to {endpoint} returned status_code "
                    + str(response.status_code)
                )
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN,
                    message="Unknown error from Keycloak endpoint.",
                )
                context.abort_with_status(rpc_status.to_status(status))
        except RoleNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Role not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            context.abort(
                code=grpc.StatusCode.UNKNOWN, details="Unknown error occurred!"
            )
