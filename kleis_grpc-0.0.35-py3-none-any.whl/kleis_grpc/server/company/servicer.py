"""Handlers for company-related/keycloak-client-related tasks.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from google.rpc import code_pb2, status_pb2
from grpc._server import _Context  # type: ignore
from grpc_status import rpc_status
from keycloak.exceptions import (  # type: ignore
    KeycloakPostError,
    KeycloakPutError,
)
from requests import Response

from kleis_grpc.const import permissions
from kleis_grpc.protos.authorization import company_pb2, company_pb2_grpc
from kleis_grpc.server import settings
from kleis_grpc.server.authorization.handlers import create_permission_bundle
from kleis_grpc.server.exceptions import CompanyNotFound, PermissionBundleFailed
from kleis_grpc.server.group.handlers import assign_group_role
from kleis_grpc.server.permission.handlers import (
    gather_full_permission_dict_by_id,
)
from kleis_grpc.server.policy.handlers import (
    full_policy_url,
    get_policy_keycloak_dict_by_name,
)
from kleis_grpc.server.role.handlers import create_role
from kleis_grpc.server.utils import keycloak_utils


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


class CompanyServicer(company_pb2_grpc.CompanyServiceServicer):
    def createCompanyClient(
        self, request: company_pb2.CreateCompanyRequest, context: _Context
    ) -> company_pb2.CreateCompanyResponse:
        """Create a client in Keycloak named after the company_key."""
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            # These fields are the bare minimum to support a client with Authz
            payload = {
                "clientId": request.company_key,
                "name": request.name,
                "publicClient": False,
                "authorizationServicesEnabled": True,
                "serviceAccountsEnabled": True,
                "directAccessGrantsEnabled": True,  # this is needed for user tokens
            }
            response = keycloak_admin.create_client(payload=payload)
            return company_pb2.CreateCompanyResponse(
                company=company_pb2.Company(
                    company_key=request.company_key,
                    name=request.name,
                    client_id=response,
                ),
            )
        except KeycloakPostError as e:
            if e.response_code == 409:
                status = status_pb2.Status(
                    code=code_pb2.ALREADY_EXISTS,
                    message="Company Keycloak client already exists.",
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))

    def createCompany(
        self, request: company_pb2.CreateCompanyRequest, context: _Context
    ) -> company_pb2.CreateCompanyResponse:
        """Create a full company, including the company client, enabling token exchange,
        and creating all default authz objects.
        """
        # Create the keycloak client and then set up default authz objects/bundles
        client_response = self.createCompanyClient(request=request, context=context)
        LOGGER.info(f'Successfully created client for "{request.company_key}"')
        try:
            self.createDefaultAuthzObjects(
                request=company_pb2.CreateDefaultAuthzObjectsRequest(
                    company_key=request.company_key
                ),
                context=context,
            )
        except Exception:
            # If this fails let's continue and report at the end
            pass
        else:
            client_response.default_authz_objects_created = True

        # Enable token-exchange on the keycloak client
        enable_token_exchange_response = company_pb2.EnableTokenExchangeResponse()
        try:

            enable_token_exchange_response = self.enableTokenExchange(
                request=company_pb2.EnableTokenExchangeRequest(
                    company_key=request.company_key
                ),
                context=context,
            )
        except Exception:
            # If this fails let's continue and report at the end
            pass
        finally:
            if not enable_token_exchange_response.enabled:
                LOGGER.error(
                    f"Company {request.company_key} successfully created, but token-exchange "
                    "was not enabled!"
                )
            else:
                client_response.token_exchange_enabled = True
        return client_response

    def createDefaultAuthzObjects(
        self, request: company_pb2.CreateDefaultAuthzObjectsRequest, context: _Context
    ) -> company_pb2.CreateDefaultAuthzObjectsResponse:
        """Create the default group, roles, and ingest a json fixture to produce
        the necessary authz resources, scopes, permissions, and policies.
        """
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        # Create a group named after the company
        try:
            keycloak_admin.create_group(payload={"name": request.company_key})
        except KeycloakPostError as e:
            if e.response_code == 409:
                LOGGER.error(f"Group named {request.company_key} already exists.")
                status = status_pb2.Status(
                    code=code_pb2.ALREADY_EXISTS, message="Group already exists."
                )
                context.abort_with_status(rpc_status.to_status(status))
            else:
                LOGGER.exception(e)
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN,
                    message="Unknown KeycloakPostError while creating group.",
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error while creating group."
            )
            context.abort_with_status(rpc_status.to_status(status))

        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND,
                message="Keycloak client not found for company.",
            )
            context.abort_with_status(rpc_status.to_status(status))

        # Create default roles and map the company-level role to the group, so that
        # all members of the company are automatically assigned.
        try:
            for role in settings.DEFAULT_ROLES:
                create_role(
                    name=role,
                    description="",
                    client_id=client_id,
                    keycloak_admin=keycloak_admin,
                )
        except KeycloakPostError as e:
            if e.response_code == 409:
                LOGGER.exception(
                    f"{role} role for {request.company_key} already exists."
                )
                status = status_pb2.Status(
                    code=code_pb2.ALREADY_EXISTS,
                    message=(
                        f"Role {role} already exists for company {request.company_key}."
                    ),
                )
                context.abort_with_status(rpc_status.to_status(status))
            else:
                LOGGER.exception(e)
                status = status_pb2.Status(
                    code=code_pb2.UNKNOWN,
                    message="Unknown KeycloakPostError while creating role.",
                )
                context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error while creating roles."
            )
            context.abort_with_status(rpc_status.to_status(status))

        try:
            assign_group_role(
                group_name=request.company_key,
                role_name=settings.COMPANY_ROLE_NAME,
                role_company_key=request.company_key,
                keycloak_admin=keycloak_admin,
            )

            # All permission names are uppercase, so this is a handy way to separate out built-ins.
            resources = [
                res
                for name, res in vars(permissions.Resource).items()
                if name.isupper()
            ]
            # Create default authz objects (resources, scopes, policies, permissions)
            for resource in resources:
                for scope in resource.scopes:
                    try:
                        create_permission_bundle(
                            resource=resource.name,
                            scope=scope,
                            company_key=request.company_key,
                            client_id=client_id,
                            resource_friendly_name=resource.display_name,
                            resource_category=resource.category,
                            keycloak_admin=keycloak_admin,
                        )
                    except Exception as e:
                        LOGGER.exception(e)
                        raise PermissionBundleFailed
        except PermissionBundleFailed:
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN,
                message="Unknown error while creating permission.",
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN,
                message="Unknown error while creating default Authz objects for company.",
            )
            context.abort_with_status(rpc_status.to_status(status))
        return company_pb2.CreateDefaultAuthzObjectsResponse()

    def _get_client_id(self, company_key: str, keycloak_admin: KeycloakAdmin) -> str:
        if not (client_id := keycloak_admin.get_client_id(company_key)):
            LOGGER.error(f"client_id not found for company_key {company_key}")
            raise CompanyNotFound
        return client_id

    def _enable_client_permissions_toggle(
        self, client_id: str, keycloak_admin: KeycloakAdmin
    ) -> Response:
        permission_endpoint = (
            f"{keycloak_admin.server_url}/admin/realms/"
            f"{keycloak_admin.connection.realm_name}/clients/"
            f"{client_id}/management/permissions"
        )
        payload = {"enabled": True}
        response = keycloak_admin.connection.raw_put(
            path=permission_endpoint,
            data=json.dumps(payload),
        )
        if not response.ok:
            LOGGER.error(
                f"Permissions endpoint for client_id {client_id} returned "
                f"response code {response.status_code}"
            )
            raise KeycloakPutError
        return response

    def _add_client_policy_to_permission(
        self,
        policy: dict,
        permission_id: str,
        realm_management_client_id: str,
        keycloak_admin: KeycloakAdmin,
    ) -> None:

        permission = gather_full_permission_dict_by_id(
            permission_id=permission_id,
            client_id=realm_management_client_id,
            keycloak_admin=keycloak_admin,
        )
        permission["policies"].append(policy["id"])
        keycloak_admin.update_client_authz_scope_permission(
            payload=permission,
            client_id=realm_management_client_id,
            scope_id=permission["id"],
        )
        return None

    def _add_client_id_to_client_policy(
        self,
        client_id: str,
        realm_management_client_id: str,
        keycloak_admin: KeycloakAdmin,
    ) -> dict:
        """Find the token-exchange policy and add the client_id to it. If it doesn't
        exist, we create it with the client_id in the payload.
        """
        policy = get_policy_keycloak_dict_by_name(
            policy_name=settings.EXCHANGE_TOKEN_PERMISSION_POLICY,
            client_id=realm_management_client_id,
            keycloak_admin=keycloak_admin,
        )
        # If the policy doesn't exist yet, we can create it with the client id in the
        # payload and just return that.
        if policy is None:
            return keycloak_admin.create_client_authz_client_policy(
                payload={
                    "type": "client",
                    "logic": "POSITIVE",
                    "name": settings.EXCHANGE_TOKEN_PERMISSION_POLICY,
                    "clients": [client_id],
                },
                client_id=realm_management_client_id,
            )
        # If the policy already exists, we need to add the client to it via raw PUT.
        elif policy is not None:
            # Convert the string contained in policy["config"]["clients"] into a regular
            # list in policy["clients"] like the endpoint expects.
            config = policy.pop("config")
            policy["clients"] = json.loads(config["clients"])

            policy["clients"].append(client_id)
            response = keycloak_admin.connection.raw_put(
                path=full_policy_url(
                    keycloak_admin=keycloak_admin,
                    client_id=realm_management_client_id,
                    policy_id=policy["id"],
                    policy_type="client",
                ),
                data=json.dumps(policy),
            )
            if not response.ok:
                LOGGER.error(
                    f"Unable to add token-exchange client {client_id} to the "
                    f'"{policy["name"]}" policy.'
                )
                raise KeycloakPutError
            return policy

    def enableTokenExchange(
        self, request: company_pb2.EnableTokenExchangeRequest, context: _Context
    ) -> company_pb2.EnableTokenExchangeResponse:
        """Set up the necessary permissions for a company (kleis client) to enable
        token exhange.
        """
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            # Enable permissions toggle at the client, and get the token-exchange
            # permission ID from the response
            token_client_id = self._get_client_id(
                company_key=request.company_key, keycloak_admin=keycloak_admin
            )

            response = self._enable_client_permissions_toggle(
                client_id=token_client_id, keycloak_admin=keycloak_admin
            )
            token_exchange_permission_id = response.json()["scopePermissions"][
                "token-exchange"
            ]
            # At the realm-management client, add the company client to the "client
            # can exchange tokens" policy.
            # This client name is a keycloak default.
            realm_management_id = keycloak_admin.get_client_id("realm-management")
            policy = self._add_client_id_to_client_policy(
                client_id=token_client_id,
                realm_management_client_id=realm_management_id,
                keycloak_admin=keycloak_admin,
            )
            # At the realm-management client, add the "client can exchange tokens"
            # policy to the permission.
            self._add_client_policy_to_permission(
                policy=policy,
                permission_id=token_exchange_permission_id,
                realm_management_client_id=realm_management_id,
                keycloak_admin=keycloak_admin,
            )
            return company_pb2.EnableTokenExchangeResponse(enabled=True)
        except CompanyNotFound:
            status = status_pb2.Status(
                code=code_pb2.NOT_FOUND, message="Company not found."
            )
            context.abort_with_status(rpc_status.to_status(status))
        except Exception as e:
            LOGGER.exception(e)
            status = status_pb2.Status(
                code=code_pb2.UNKNOWN, message="Unknown error occurred."
            )
            context.abort_with_status(rpc_status.to_status(status))
