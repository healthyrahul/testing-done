from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from grpc._server import _Context  # type: ignore
from keycloak.exceptions import KeycloakPostError  # type: ignore

from kleis_grpc.protos.authorization import scope_pb2, scope_pb2_grpc
from kleis_grpc.server.scope.handlers import create_scope, get_scope_by_name
from kleis_grpc.server.utils import keycloak_utils


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


class ScopeServicer(scope_pb2_grpc.ScopeServiceServicer):
    def _build_scope_url(
        self, keycloak_admin: KeycloakAdmin, client_id: str, scope_id: str
    ) -> str:
        return (
            f"{keycloak_admin.server_url}/admin/realms/"
            f"{keycloak_admin.connection.realm_name}/clients/"
            f"{client_id}/authz/resource-server/scope/{scope_id}"
        )

    def createScope(
        self, request: scope_pb2.ScopeRequest, context: _Context
    ) -> scope_pb2.ScopeResponse:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        try:
            keycloak_admin = keycloak_utils.get_keycloak_admin()
            if not (client_id := keycloak_admin.get_client_id(request.company_key)):
                LOGGER.error(
                    f"client_id not found for company_key {request.company_key}"
                )
            response = create_scope(
                name=request.name, client_id=client_id, keycloak_admin=keycloak_admin
            )
            return scope_pb2.ScopeResponse(
                status=scope_pb2.SCOPE_OK,
                scope=scope_pb2.Scope(
                    name=response["name"],
                    id=response["id"],
                    company_key=request.company_key,
                    client_id=client_id,
                ),
            )
        except KeycloakPostError as e:
            if e.response_code == 409:
                return scope_pb2.ScopeResponse(
                    status=scope_pb2.SCOPE_ALREADY_EXISTS,
                )
            elif e.response_code == 404:
                return scope_pb2.ScopeResponse(
                    status=scope_pb2.SCOPE_COMPANY_KEY_NOT_FOUND,
                )
            else:
                return scope_pb2.ScopeResponse(
                    status=scope_pb2.SCOPE_UNKNOWN_ERROR,
                )
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(
                status=scope_pb2.SCOPE_UNKNOWN_ERROR,
            )

    def renameScope(
        self, request: scope_pb2.RenameScopeRequest, context: _Context
    ) -> scope_pb2.ScopeResponse:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_COMPANY_KEY_NOT_FOUND)
        # Get existing values so we don't zero these out by accident later
        try:
            existing_scope = get_scope_by_name(
                scope_name=request.name,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            if existing_scope is None:
                return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_NOT_FOUND)
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)

        # Build payload based on existing scope so we don't drop anything. Items
        # left out will be zeroed out by keycloak.
        new_values = {}
        if request.new_name != "":
            new_values["name"] = request.new_name
        payload = existing_scope | new_values

        # python-keycloak does not currently have a function for updating client authz
        # scopes, so we have to do a raw PUT here.
        try:
            response = keycloak_admin.connection.raw_put(
                path=self._build_scope_url(
                    keycloak_admin=keycloak_admin,
                    client_id=client_id,
                    scope_id=existing_scope["id"],
                ),
                data=json.dumps(payload),
            )
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(
                status=scope_pb2.SCOPE_UNKNOWN_ERROR,
            )

        if response.status_code == 204:
            return scope_pb2.ScopeResponse(
                status=scope_pb2.SCOPE_OK,
                scope=scope_pb2.Scope(
                    name=payload["name"],
                    id=payload["id"],
                    company_key=request.company_key,
                    client_id=client_id,
                ),
            )
        else:
            LOGGER.error(
                f"PUT request for scope/{payload['id']} returned status_code "
                f"{response.status_code}"
            )
            return scope_pb2.ScopeResponse(
                status=scope_pb2.SCOPE_UNKNOWN_ERROR,
            )

    def listScopesByCompany(
        self, request: scope_pb2.ScopesByCompanyRequest, context: _Context
    ) -> scope_pb2.ScopeResponse:
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            yield scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_COMPANY_KEY_NOT_FOUND)
            return
        try:
            scopes = keycloak_admin.get_client_authz_scopes(client_id=client_id)
            for scope in scopes:
                yield scope_pb2.ScopeResponse(
                    status=scope_pb2.SCOPE_OK,
                    scope=scope_pb2.Scope(
                        name=scope["name"],
                        id=scope["id"],
                        company_key=request.company_key,
                        client_id=client_id,
                    ),
                )
        except Exception as e:
            LOGGER.exception(e)
            yield scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)
            return

    def deleteScope(
        self, request: scope_pb2.ScopeRequest, context: _Context
    ) -> scope_pb2.ScopeResponse:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_COMPANY_KEY_NOT_FOUND)
        try:
            scope = get_scope_by_name(
                scope_name=request.name,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            if scope is None:
                return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_NOT_FOUND)
            response = keycloak_admin.connection.raw_delete(
                path=self._build_scope_url(
                    keycloak_admin=keycloak_admin,
                    client_id=client_id,
                    scope_id=scope["id"],
                )
            )
            if response.status_code == 204:
                return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_OK)
            elif response.status_code == 404:
                return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_NOT_FOUND)
            else:
                LOGGER.error(
                    f"DELETE request for scope/{scope['id']} returned status_code "
                    f"{response.status_code}"
                )
                return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)

    def getScope(
        self, request: scope_pb2.ScopeRequest, context: _Context
    ) -> scope_pb2.ScopeResponse:
        if not (request.company_key):
            raise ValueError("company_key is required.")
        keycloak_admin = keycloak_utils.get_keycloak_admin()
        if not (client_id := keycloak_admin.get_client_id(request.company_key)):
            LOGGER.error(f"client_id not found for company_key {request.company_key}")
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_COMPANY_KEY_NOT_FOUND)
        try:
            scope = get_scope_by_name(
                scope_name=request.name,
                client_id=client_id,
                keycloak_admin=keycloak_admin,
            )
            if scope is None:
                return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_NOT_FOUND)
            return scope_pb2.ScopeResponse(
                status=scope_pb2.SCOPE_OK,
                scope=scope_pb2.Scope(
                    name=scope["name"],
                    id=scope["id"],
                    company_key=request.company_key,
                    client_id=client_id,
                ),
            )
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)
