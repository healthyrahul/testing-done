"""Handlers for scope-related tasks.

Unless absolutely necessary, a handler should never instatiate a KeycloakAdmin object,
but should accept it as an argument, to be instantiated by a GRPC servicer.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional


if TYPE_CHECKING:
    from keycloak import KeycloakAdmin

LOGGER = logging.getLogger(__name__)


def get_scope_by_name(
    scope_name: str, client_id: str, keycloak_admin: KeycloakAdmin
) -> Optional[dict]:
    scopes = keycloak_admin.get_client_authz_scopes(client_id=client_id)
    scope = next((scope for scope in scopes if scope["name"] == scope_name), None)
    return scope


def create_scope(
    name: str,
    client_id: str,
    keycloak_admin: KeycloakAdmin,
) -> dict:
    return keycloak_admin.create_client_authz_scopes(
        client_id=client_id,
        payload={"name": name},
    )
