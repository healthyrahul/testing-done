"""Client SDK for interacting with Kleis."""
# pylint: disable=no-member
from __future__ import print_function

import logging
from typing import List, Optional

import grpc

from kleis_grpc.protos.authentication import (
    login_pb2,
    login_pb2_grpc,
    token_manager_pb2_grpc,
    user_pb2_grpc,
)
from kleis_grpc.protos.authorization import (
    authorization_pb2,
    authorization_pb2_grpc,
    company_pb2,
    company_pb2_grpc,
    group_pb2,
    group_pb2_grpc,
    permission_pb2,
    permission_pb2_grpc,
    policy_pb2,
    policy_pb2_grpc,
    resource_pb2,
    resource_pb2_grpc,
    role_pb2,
    role_pb2_grpc,
    scope_pb2,
    scope_pb2_grpc,
)
from kleis_grpc.protos.general import statuses_pb2
from kleis_grpc.server import settings


LOGGER = logging.getLogger()


class Groups:
    def __init__(self, channel):
        self.group_service_stub = group_pb2_grpc.GroupServiceStub(channel)

    def _create_group(self, name: str) -> group_pb2.Group:
        try:
            return self.group_service_stub.createGroup(
                group_pb2.GroupRequest(name=name)
            )
        except Exception as e:
            LOGGER.exception(e)
            return group_pb2.Group()

    def _assign_group_role(
        self, group_name: str, role_name: str, company_key: str
    ) -> group_pb2.Group:
        try:
            return self.group_service_stub.assignGroupRole(
                group_pb2.GroupAndRoleRequest(
                    group_name=group_name,
                    role_name=role_name,
                    role_company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return group_pb2.Group()

    def _remove_group_role(
        self, group_name: str, role_name: str, company_key: str
    ) -> group_pb2.Group:
        try:
            return self.group_service_stub.removeGroupRole(
                group_pb2.GroupAndRoleRequest(
                    group_name=group_name,
                    role_name=role_name,
                    role_company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return group_pb2.Group()

    def _delete_group(self, name: str) -> group_pb2.Group:
        try:
            return self.group_service_stub.deleteGroup(
                group_pb2.GroupRequest(name=name)
            )
        except Exception as e:
            LOGGER.exception(e)
            return group_pb2.Group()

    def stream_group_members(self, name: str) -> group_pb2.GroupMember:
        try:
            yield from self.group_service_stub.listGroupMembers(
                group_pb2.GroupRequest(name=name)
            )
        except Exception as e:
            LOGGER.exception(e)
            yield group_pb2.GroupMember()
            return

    def list_group_members(self, name: str) -> List[group_pb2.GroupMember]:
        return list(self.stream_group_members(name=name))

    def stream_group_roles(self, name: str) -> role_pb2.Role:
        try:
            yield from self.group_service_stub.listGroupRoles(
                group_pb2.GroupRequest(name=name)
            )
        except Exception as e:
            LOGGER.exception(e)
            yield role_pb2.Role()
            return

    def list_group_roles(self, name: str) -> List[role_pb2.Role]:
        return list(self.stream_group_roles(name=name))

    def assign_group_member(self, group_name: str, username: str) -> group_pb2.Group:
        try:
            return self.group_service_stub.assignGroupMember(
                group_pb2.GroupAndMemberRequest(
                    group_name=group_name,
                    username=username,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return group_pb2.Group()

    def remove_group_member(self, group_name: str, username: str) -> group_pb2.Group:
        try:
            return self.group_service_stub.removeGroupMember(
                group_pb2.GroupAndMemberRequest(
                    group_name=group_name,
                    username=username,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return group_pb2.Group()

    def get_group(self, name: str) -> group_pb2.Group:
        """Get group name/id combo."""
        try:
            return self.group_service_stub.getGroup(group_pb2.GroupRequest(name=name))
        except Exception as e:
            LOGGER.exception(e)
            return group_pb2.Group()

    def get_full_group(self, name: str) -> group_pb2.Group:
        """Get the full group object (including members and roles)."""
        try:
            return self.group_service_stub.getFullGroup(
                group_pb2.GroupRequest(name=name)
            )
        except Exception as e:
            LOGGER.exception(e)
            return group_pb2.Group()


class Roles:
    def __init__(self, channel):
        self.role_service_stub = role_pb2_grpc.RoleServiceStub(channel)

    def create_role(
        self, name: str, company_key: str, description: Optional[str] = None
    ) -> role_pb2.Role:
        """Creates a Keycloak client role for a client that matches provided
        company_key.
        """
        try:
            return self.role_service_stub.createRole(
                role_pb2.CreateRoleRequest(
                    name=name,
                    company_key=company_key,
                    description=description if description else None,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.Role()

    def update_role(
        self,
        name: str,
        company_key: str,
        new_name: Optional[str] = None,
        new_description: Optional[str] = None,
    ) -> role_pb2.Role:
        """Updates the name and/or description for a given role."""
        try:
            return self.role_service_stub.updateRole(
                role_pb2.UpdateRoleRequest(
                    name=name,
                    company_key=company_key,
                    new_name=new_name,
                    new_description=new_description,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.Role()

    def add_propagated_companies_to_role(
        self,
        role_name: str,
        role_company_key: str,
        propagated_company_keys: List[str],
    ) -> role_pb2.Role:
        """Add multiple company_keys to the "propagated_companies" attribute for a Role
        and propagate existing permission settings to new company_keys.
        """
        try:
            return self.role_service_stub.addPropagatedCompaniesToRole(
                role_pb2.PropagateRoleRequest(
                    role_name=role_name,
                    role_company_key=role_company_key,
                    propagated_company_keys=propagated_company_keys,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.Role()

    def remove_propagated_companies_from_role(
        self,
        role_name: str,
        role_company_key: str,
        propagated_company_keys: List[str],
    ) -> role_pb2.Role:
        """Remove a list of company_keys from the "propagated_companies" attribute for a
        Role and remove permission settings for that role from each of the previously
        propagated company_keys.
        """
        try:
            return self.role_service_stub.removePropagatedCompaniesFromRole(
                role_pb2.PropagateRoleRequest(
                    role_name=role_name,
                    role_company_key=role_company_key,
                    propagated_company_keys=propagated_company_keys,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.Role()

    def set_propagated_companies_for_role(
        self,
        role_name: str,
        role_company_key: str,
        propagated_company_keys: List[str],
    ) -> role_pb2.Role:
        """Takes a list of company_keys and sets the role's propagated_companies
        attribute to match, propagating existing permissions to any new companies, and
        unpropagating them from any companies that have been removed."""
        try:
            return self.role_service_stub.setPropagatedCompanies(
                role_pb2.PropagateRoleRequest(
                    role_name=role_name,
                    role_company_key=role_company_key,
                    propagated_company_keys=propagated_company_keys,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.Role()

    def stream_assigned_company_roles_by_user(
        self, username: str, company_key: str
    ) -> role_pb2.Role:
        """Returns a generator that yields individual company Role objects assigned
        to a specific user.
        """
        try:
            yield from self.role_service_stub.listAssignedCompanyRolesByUser(
                role_pb2.AssignedCompanyRolesByUserRequest(
                    username=username, company_key=company_key
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            yield role_pb2.Role()
            return

    def list_assigned_company_roles_by_user(
        self, username: str, company_key: str
    ) -> List[role_pb2.Role]:
        """Returns a list of company Role objects assigned to a specific user."""
        return list(
            self.stream_assigned_company_roles_by_user(
                username=username, company_key=company_key
            )
        )

    def stream_roles_by_company(self, company_key: str) -> role_pb2.Role:
        """Returns a generator that yields individual role objects."""
        try:
            yield from self.role_service_stub.listRolesByCompany(
                role_pb2.RolesByCompanyRequest(company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            yield role_pb2.Role()
            return

    def list_roles_by_company(self, company_key: str) -> List[role_pb2.Role]:
        """Returns a list of Role objects."""
        return list(self.stream_roles_by_company(company_key=company_key))

    def stream_assigned_users_by_role(
        self, name: str, company_key: str
    ) -> role_pb2.UserResponse:
        """Returns a generator that yields individual user objects."""
        try:
            yield from self.role_service_stub.listAssignedUsersByRole(
                role_pb2.RoleRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            yield role_pb2.UserResponse()
            return

    def list_assigned_users_by_role(
        self, name: str, company_key: str
    ) -> List[role_pb2.UserResponse]:
        """Returns a list of user objects."""
        return list(
            self.stream_assigned_users_by_role(name=name, company_key=company_key)
        )

    def delete_role(self, name: str, company_key: str) -> role_pb2.Role:
        """Delete role by name/company_key."""
        try:
            return self.role_service_stub.deleteRole(
                role_pb2.RoleRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.Role()

    def get_role(self, name: str, company_key: str) -> role_pb2.Role:
        """Returns the entire Role object given just a name and company_key."""
        try:
            return self.role_service_stub.getRole(
                role_pb2.RoleRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.Role()

    def add_role_to_user(
        self, username: str, role_name: str, role_company_key: str
    ) -> role_pb2.UserResponse:
        """Add a role mapping to a user."""
        try:
            return self.role_service_stub.addRoleToUser(
                role_pb2.UserRoleRequest(
                    username=username,
                    role_name=role_name,
                    role_company_key=role_company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.UserResponse()

    def remove_role_from_user(
        self, username: str, role_name: str, role_company_key: str
    ) -> role_pb2.UserResponse:
        """Remove a role mapping from a user."""
        try:
            return self.role_service_stub.removeRoleFromUser(
                role_pb2.UserRoleRequest(
                    username=username,
                    role_name=role_name,
                    role_company_key=role_company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return role_pb2.UserResponse()


class Scopes:
    def __init__(self, channel):
        self.scope_service_stub = scope_pb2_grpc.ScopeServiceStub(channel)

    def _create_scope(self, name: str, company_key: str) -> scope_pb2.ScopeResponse:
        """Create scope by name/company_key."""
        try:
            return self.scope_service_stub.createScope(
                scope_pb2.ScopeRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)

    def _rename_scope(
        self, current_name: str, new_name: str, company_key: str
    ) -> scope_pb2.ScopeResponse:
        """Rename a scope (there are no other attributes that can be changed)."""
        try:
            return self.scope_service_stub.renameScope(
                scope_pb2.RenameScopeRequest(
                    name=current_name, company_key=company_key, new_name=new_name
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)

    def _stream_scopes_by_company(self, company_key: str) -> scope_pb2.ScopeResponse:
        """Yield individual scopes by company_key."""
        try:
            yield from self.scope_service_stub.listScopesByCompany(
                scope_pb2.ScopesByCompanyRequest(company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            yield scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)
            return

    def _list_scopes_by_company(
        self, company_key: str
    ) -> List[scope_pb2.ScopeResponse]:
        """Return list of scopes for company_key."""
        return list(self._stream_scopes_by_company(company_key=company_key))

    def _delete_scope(self, name: str, company_key: str) -> scope_pb2.ScopeResponse:
        """Delete scope by name/company_key."""
        try:
            return self.scope_service_stub.deleteScope(
                scope_pb2.ScopeRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)

    def _get_scope(self, name: str, company_key: str) -> scope_pb2.ScopeResponse:
        """Returns entire scope object given name/company_key."""
        try:
            return self.scope_service_stub.getScope(
                scope_pb2.ScopeRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return scope_pb2.ScopeResponse(status=scope_pb2.SCOPE_UNKNOWN_ERROR)


class Resources:
    def __init__(self, channel):
        self.resource_service_stub = resource_pb2_grpc.ResourceServiceStub(channel)

    def _create_resource(
        self,
        name: str,
        company_key: str,
        category: str,
        friendly_name: str,
        scopes: Optional[List[str]] = None,
    ) -> resource_pb2.Resource:
        """Create resource by name/company_key."""
        try:
            return self.resource_service_stub.createResource(
                resource_pb2.CreateResourceRequest(
                    name=name,
                    company_key=company_key,
                    category=category,
                    friendly_name=friendly_name,
                    scopes=scopes,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return resource_pb2.Resource()

    def _rename_resource(
        self,
        current_name: str,
        company_key: str,
        new_name: Optional[str] = None,
    ) -> resource_pb2.Resource:
        """Update name of a resource."""
        try:
            return self.resource_service_stub.renameResource(
                resource_pb2.RenameResourceRequest(
                    name=current_name,
                    new_name=new_name,
                    company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return resource_pb2.Resource()

    def _stream_resources_by_company(self, company_key: str) -> resource_pb2.Resource:
        """Yield individual resources by company_key."""
        try:
            yield from self.resource_service_stub.listResourcesByCompany(
                resource_pb2.ResourcesByCompanyRequest(company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            yield resource_pb2.Resource()
            return

    def _list_resources_by_company(
        self, company_key: str
    ) -> List[resource_pb2.Resource]:
        """Return list of resources for company_key."""
        return list(self._stream_resources_by_company(company_key=company_key))

    def _delete_resource(self, name: str, company_key: str) -> resource_pb2.Resource:
        """Delete resource by name/company_key."""
        try:
            return self.resource_service_stub.deleteResource(
                resource_pb2.ResourceRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return resource_pb2.Resource()

    def _get_resource(self, name: str, company_key: str) -> resource_pb2.Resource:
        """Returns entire resource object given name/company_key."""
        try:
            return self.resource_service_stub.getResource(
                resource_pb2.ResourceRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return resource_pb2.Resource()


class Policies:
    def __init__(self, channel):
        self.policy_service_stub = policy_pb2_grpc.PolicyServiceStub(channel)
        self.roles = Roles(channel)

    def _create_role_policy(
        self,
        name: str,
        company_key: str,
        roles: Optional[List[str]] = None,
        logic: Optional[str] = None,
    ) -> policy_pb2.Policy:
        if logic is None:
            logic = settings.DEFAULT_POLICY_TYPE
        try:
            return self.policy_service_stub.createPolicy(
                policy_pb2.CreatePolicyRequest(
                    name=name,
                    company_key=company_key,
                    logic=logic,
                    type="role",
                    roles=[
                        policy_pb2.CreatePolicyRequest.Role(
                            name=role, company_key=company_key
                        )
                        for role in (roles if roles is not None else [])
                    ],
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return policy_pb2.Policy()

    def _rename_role_policy(
        self, name: str, company_key: str, new_name: str
    ) -> policy_pb2.Policy:
        try:
            return self.policy_service_stub.renamePolicy(
                policy_pb2.RenamePolicyRequest(
                    name=name,
                    new_name=new_name,
                    company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return policy_pb2.Policy()

    def _get_policy(self, name: str, company_key: str) -> policy_pb2.Policy:
        try:
            return self.policy_service_stub.getPolicy(
                policy_pb2.PolicyRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return policy_pb2.Policy()

    def _stream_policies_by_company(self, company_key: str) -> policy_pb2.Policy:
        try:
            yield from self.policy_service_stub.listPoliciesByCompany(
                policy_pb2.PoliciesByCompanyRequest(company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            yield policy_pb2.Policy()
            return

    def _list_policies_by_company(self, company_key: str) -> List[policy_pb2.Policy]:
        return list(self._stream_policies_by_company(company_key=company_key))

    def _delete_policy(self, name: str, company_key: str) -> policy_pb2.Policy:
        try:
            return self.policy_service_stub.deletePolicy(
                policy_pb2.PolicyRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return policy_pb2.Policy()


class Permissions:
    def __init__(self, channel):
        self.permission_service_stub = permission_pb2_grpc.PermissionServiceStub(
            channel
        )
        self.authorization_service_stub = (
            authorization_pb2_grpc.AuthorizationServiceStub(channel)
        )
        self.resources = Resources(channel)

    def get_permission(self, name: str, company_key: str) -> permission_pb2.Permission:
        try:
            return self.permission_service_stub.getPermission(
                permission_pb2.PermissionRequest(
                    name=name,
                    company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return permission_pb2.Permission()

    def _rename_permission(
        self, name: str, company_key: str, new_name: str
    ) -> permission_pb2.Permission:
        try:
            return self.permission_service_stub.renamePermission(
                permission_pb2.RenamePermissionRequest(
                    name=name,
                    company_key=company_key,
                    new_name=new_name,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return permission_pb2.Permission()

    def _delete_keycloak_permission(
        self, name: str, company_key: str
    ) -> permission_pb2.Permission:
        """Deletes only the keycloak permission object, not any resources, scopes, or
        policies that were created for it.
        """
        try:
            return self.permission_service_stub.deletePermission(
                permission_pb2.PermissionRequest(name=name, company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            return permission_pb2.Permission()

    def stream_permissions_by_company(
        self, company_key: str
    ) -> permission_pb2.Permission:
        try:
            yield from self.permission_service_stub.listPermissionsByCompany(
                permission_pb2.PermissionsByCompanyRequest(company_key=company_key)
            )
        except Exception as e:
            LOGGER.exception(e)
            yield permission_pb2.Permission()
            return

    def list_permissions_by_company(
        self,
        company_key: str,
    ) -> List[permission_pb2.Permission]:
        return list(self.stream_permissions_by_company(company_key=company_key))

    def stream_permissions_by_resource(
        self,
        resource_name: str,
        company_key: str,
    ) -> permission_pb2.Permission:
        try:
            yield from self.permission_service_stub.listPermissionsByResource(
                permission_pb2.PermissionsByResourceRequest(
                    resource_name=resource_name, company_key=company_key
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            yield permission_pb2.Permission()
            return

    def list_permissions_by_resource(
        self,
        resource_name: str,
        company_key: str,
    ) -> List[permission_pb2.Permission]:
        return list(
            self.stream_permissions_by_resource(
                resource_name=resource_name, company_key=company_key
            )
        )

    def create_permission(
        self,
        resource: str,
        scope: str,
        company_key: str,
        resource_friendly_name: Optional[str] = "",
        resource_category: Optional[str] = "",
    ) -> permission_pb2.Permission:
        """Create a permission, automatically generating the full "permission bundle"
        (scope, resource, role policies, and permission object that associates them
        all). It maintains a 1:1 relationship between scope and resource to keep it most
        compatible with with existing ecosystem (hermes, artemis-app).
        """
        try:
            return self.authorization_service_stub.createPermissionBundle(
                authorization_pb2.CreatePermissionBundleRequest(
                    resource=resource,
                    scope=scope,
                    company_key=company_key,
                    resource_friendly_name=resource_friendly_name,
                    resource_category=resource_category,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return permission_pb2.Permission()

    def evaluate_permission(
        self, access_token: str, resource: str, scope: str, company_key: str
    ) -> authorization_pb2.EvaluatePermissionResponse:
        try:
            return self.authorization_service_stub.evaluatePermission(
                authorization_pb2.EvaluatePermissionRequest(
                    access_token=access_token,
                    resource=resource,
                    scope=scope,
                    company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return authorization_pb2.EvaluatePermissionResponse()

    def enable_permission_for_role(
        self,
        resource: str,
        scope: str,
        role_name: str,
        company_key: str,
    ) -> authorization_pb2.PermissionToggleResponse:
        """Takes a permission resource, scope, role name, and company key and enables
        the permission for the role (by assigning the role to the role policy for that
        permission in keycloak).
        """
        try:
            return self.authorization_service_stub.enablePermissionForRole(
                authorization_pb2.PermissionToggleRequest(
                    scope=scope,
                    resource=resource,
                    role_name=role_name,
                    company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return authorization_pb2.PermissionToggleResponse()

    def disable_permission_for_role(
        self,
        resource: str,
        scope: str,
        role_name: str,
        company_key: str,
    ) -> authorization_pb2.PermissionToggleResponse:
        """Takes a permission resource, scope, role name, and company key, and disables
        the permission for a role (by removing the role from the role policy for the
        permission in keycloak).
        """
        try:
            return self.authorization_service_stub.disablePermissionForRole(
                authorization_pb2.PermissionToggleRequest(
                    scope=scope,
                    resource=resource,
                    role_name=role_name,
                    company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return authorization_pb2.PermissionToggleResponse()

    def get_permission_status_for_role(
        self, scope: str, resource: str, role_name: str, company_key: str
    ) -> authorization_pb2.RolePermissionResponse:
        """Check if a permission is enabled and visible for a specific role."""
        try:
            return self.authorization_service_stub.getPermissionStatusForRole(
                authorization_pb2.PermissionStatusForRoleRequest(
                    scope=scope,
                    resource=resource,
                    role_name=role_name,
                    company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            return authorization_pb2.RolePermissionResponse()

    def stream_all_permission_statuses_for_role(
        self,
        role_name: str,
        company_key: str,
    ) -> authorization_pb2.RolePermissionResponse:
        """Get all permissions and statuses for a given role and stream the responses."""
        try:
            yield from self.authorization_service_stub.getAllPermissionStatusesForRole(
                authorization_pb2.AllPermissionStatusesForRoleRequest(
                    role_name=role_name,
                    company_key=company_key,
                )
            )
        except Exception as e:
            LOGGER.exception(e)
            yield authorization_pb2.RolePermissionResponse()
            return

    def list_all_permission_statuses_for_role(
        self,
        role_name: str,
        company_key: str,
    ) -> authorization_pb2.RolePermissionResponse:
        """Get all permissions and statuses for a given role and list the responses."""
        return list(
            self.stream_all_permission_statuses_for_role(
                role_name=role_name, company_key=company_key
            )
        )


class Companies:
    def __init__(self, channel):
        self.company_service_stub = company_pb2_grpc.CompanyServiceStub(channel)

    def create_company(
        self, company_key: str, name: str
    ) -> company_pb2.CreateCompanyResponse:
        """Create a company client with clientId (keycloak's human readable id field)
        set to the supplied company_key. Once the company client has been created,
        create all default group(s), roles, resources, scopes, permissions, and
        policies.
        """
        try:
            return self.company_service_stub.createCompany(
                company_pb2.CreateCompanyRequest(company_key=company_key, name=name)
            )
        except Exception as e:
            LOGGER.exception(e)
            return company_pb2.CreateCompanyResponse()


class Kleis:  # pylint: disable=too-few-public-methods
    """Everything below here should be easy."""

    def __init__(self, host):
        """Initialize the kleis client."""
        self.host = host
        self.channel = grpc.insecure_channel(host)
        self.login_stub = login_pb2_grpc.LoginStub(self.channel)
        self.token_manager_stub = token_manager_pb2_grpc.TokenManagerStub(self.channel)
        self.user_stub = user_pb2_grpc.UserStub(self.channel)
        self.permissions = Permissions(self.channel)
        self.roles = Roles(self.channel)
        self.scopes = Scopes(self.channel)
        self.resources = Resources(self.channel)
        self.policies = Policies(self.channel)
        self.groups = Groups(self.channel)
        self.companies = Companies(self.channel)

    def password_login(self, user_id: str, password: str) -> login_pb2.LoginResponse:
        """Login with a username and password.

        :param user_id: The user's unique id.
            This is almost always an email address in the Artemis Ecosystem.
        :param password: The user's password.
        :return LoginResponse:
        """
        try:
            resp = self.login_stub.passwordLogin(
                login_pb2.PasswordLoginRequest(
                    user_id=user_id,
                    password=password,
                )
            )
        except Exception:  # pylint: disable=broad-exception-caught
            LOGGER.exception("Unexpected Error When Logging In")
            resp = login_pb2.LoginResponse(status=statuses_pb2.UNKNOWN)
        return resp

    def idp_initiated_login(self, saml_assertion: str) -> login_pb2.LoginResponse:
        """Login with a SAML assertion.

        :param saml_assertion: A base64 encoded SAML assertion from a valid IdP.
        :return LoginResponse:
        """
        try:
            resp = self.login_stub.IDPInitiatedLogin(
                login_pb2.IDPInitiatedLoginRequest(
                    saml_assertion=saml_assertion,
                )
            )
        except Exception:  # pylint: disable=broad-exception-caught
            LOGGER.exception("Unexpected Error When Logging In")
            resp = login_pb2.LoginResponse(status=statuses_pb2.UNKNOWN)
        return resp

    def generate_sp_initiated_login_request(
        self, username: str, frontend_destination: str
    ) -> login_pb2.GenerateSPInitiatedLoginResponse:
        """Generate an SP initiated Login Request.

        :param username: The username of the user attempting login.
        :param frontend_destination: The frontend destination of the saml assertion.
            This is necessary because any intermediaries proxy the assertion into kleis.
            Should be of the form: http://example.com/optional/path?optional=params
        :return GenerateSPInitiatedLoginResponse:
        """
        try:
            resp = self.login_stub.GenerateSPInitiatedLogin(
                login_pb2.GenerateSPInitiatedLoginRequest(
                    username=username,
                    frontend_destination=frontend_destination,
                )
            )
        except Exception:  # pylint: disable=broad-exception-caught
            LOGGER.exception("Unexpected Error When Logging In")
            resp = login_pb2.GenerateSPInitiatedLoginResponse(
                status=statuses_pb2.UNKNOWN
            )
        return resp

    def sp_initiated_login(
        self, saml_assertion, session_id, relay_state
    ) -> login_pb2.LoginResponse:
        """Perform a user login from a SAML assertion generated by the IdP in
        response to an SP initiated SAML request.

        :param saml_assertion: The
        :param session_id: The keycloak session_id generated with the SAML request.
            This must be the same session_id that was returned from kleis.generate_sp_initiated_login_request().
        :param relay_state: The relay state generated by keycloak and returned by the IdP.
        :return: LoginResponse:
        """
        try:
            resp = self.login_stub.SPInitiatedLogin(
                login_pb2.SPInitiatedLoginRequest(
                    saml_assertion=saml_assertion,
                    session_id=session_id,
                    relay_state=relay_state,
                )
            )
        except Exception:  # pylint: disable=broad-exception-caught
            LOGGER.exception("Unexpected Error When Logging In")
            resp = login_pb2.LoginResponse(status=statuses_pb2.UNKNOWN)
        return resp
