import os
import yaml


BALLISTA_YAML_PATH = "kleis_grpc/ballista.yml"
SDK_NAME_KEY = "kleis-python-sdk"
VERSION_KEY = "build_version"


def get_version():
    """Extract the SDK version from the ballista.yml.

    This function makes two big assumptions:
    - The script is being run from the root directory of the repo.
    - The ballista.yml has been copied into the path kleis_grpc/ballista.yml.
      - This is handled by the Dockerfile. If you are manually building, you'll
        have to do this by hand.
    """
    with open(BALLISTA_YAML_PATH, encoding='UTF-8') as ballista_yml:
        ballista_contents = yaml.safe_load(ballista_yml)
    python_sdk = [artifact for artifact in ballista_contents['artifacts'] if artifact["name_key"] == SDK_NAME_KEY][0]
    version = python_sdk[VERSION_KEY]
    return version


VERSION = get_version()
